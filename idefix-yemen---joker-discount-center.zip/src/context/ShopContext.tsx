import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, CustomerOrder, CategoryId, GroupDeal } from '../types';
import { INITIAL_PRODUCTS, INITIAL_GROUP_DEALS } from '../data/initialProducts';

interface Coupon {
  code: string;
  discountAmount: number;
  label: string;
}

interface ShopContextType {
  products: Product[];
  cart: CartItem[];
  orders: CustomerOrder[];
  groupDeals: GroupDeal[];
  searchQuery: string;
  selectedCategory: CategoryId;
  selectedProduct: Product | null;
  isCartOpen: boolean;
  isCheckoutOpen: boolean;
  isAdminOpen: boolean;
  isGroupBuyingOpen: boolean;
  isInviteModalOpen: boolean;
  activeCoupon: Coupon | null;
  lastCompletedOrder: CustomerOrder | null;
  
  // Cart Actions
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, newQuantity: number) => void;
  clearCart: () => void;
  
  // Coupon Actions
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  
  // Order Actions
  placeOrder: (orderInput: {
    customerName: string;
    phoneNumber: string;
    deliveryAddress: string;
    notes?: string;
    paymentMethod: 'cod' | 'kuraimi_onecash';
  }) => CustomerOrder;
  
  // Admin Product Actions
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  resetProductsToDefault: () => void;
  
  // Group Deals Action
  joinGroupDeal: (dealId: string) => void;

  // UI state setters
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: CategoryId) => void;
  setSelectedProduct: (product: Product | null) => void;
  setIsCartOpen: (open: boolean) => void;
  setIsCheckoutOpen: (open: boolean) => void;
  setIsAdminOpen: (open: boolean) => void;
  setIsGroupBuyingOpen: (open: boolean) => void;
  setIsInviteModalOpen: (open: boolean) => void;
  setLastCompletedOrder: (order: CustomerOrder | null) => void;

  // Computations
  cartCount: number;
  cartSubtotal: number;
  cartDiscount: number;
  cartTotal: number;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

const LOCAL_STORAGE_PRODUCTS = 'idefix_yemen_products';
const LOCAL_STORAGE_CART = 'idefix_yemen_cart';
const LOCAL_STORAGE_ORDERS = 'idefix_yemen_orders';
const LOCAL_STORAGE_GROUP_DEALS = 'idefix_yemen_group_deals';

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Products state
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_PRODUCTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading products from localStorage', e);
    }
    return INITIAL_PRODUCTS;
  });

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CART);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading cart from localStorage', e);
    }
    return [];
  });

  // Orders state (demo admin view)
  const [orders, setOrders] = useState<CustomerOrder[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ORDERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading orders from localStorage', e);
    }
    return [
      {
        id: 'JKR-1092',
        customerName: 'صالح محمد الحبيشي',
        phoneNumber: '771234567',
        deliveryAddress: 'يريم - شارع 20 - عمارة الشامي بجوار الصيدلية',
        notes: 'يرجى الاتصال قبل الوصول للتوصيل السريع',
        paymentMethod: 'cod',
        items: [
          {
            productId: 'prod-1',
            productName: 'سكر السعيد نقي فاخر (10 كجم)',
            unit: 'كيس 10 كجم',
            quantity: 1,
            price: 11800,
            total: 11800,
          },
          {
            productId: 'prod-4',
            productName: 'مسحوق غسيل تايد مركز بقوة الليمون (4 كجم)',
            unit: 'كيس 4 كجم',
            quantity: 2,
            price: 6400,
            total: 12800,
          },
        ],
        subtotal: 24600,
        discountAmount: 1000,
        couponCode: 'JOKER-YARIM',
        total: 23600,
        createdAt: 'اليوم، 10:15 صباحاً',
        status: 'confirmed',
      },
    ];
  });

  // Group deals state
  const [groupDeals, setGroupDeals] = useState<GroupDeal[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_GROUP_DEALS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Error reading group deals from localStorage', e);
    }
    return INITIAL_GROUP_DEALS;
  });

  // Search & Navigation
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Modals & Panels
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isGroupBuyingOpen, setIsGroupBuyingOpen] = useState(false);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [lastCompletedOrder, setLastCompletedOrder] = useState<CustomerOrder | null>(null);

  // Coupons
  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);

  // Synchronize localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_PRODUCTS, JSON.stringify(products));
    } catch (e) {
      console.warn('Error saving products to localStorage', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_CART, JSON.stringify(cart));
    } catch (e) {
      console.warn('Error saving cart to localStorage', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.warn('Error saving orders to localStorage', e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_GROUP_DEALS, JSON.stringify(groupDeals));
    } catch (e) {
      console.warn('Error saving group deals to localStorage', e);
    }
  }, [groupDeals]);

  // Cart operations
  const addToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setActiveCoupon(null);
  };

  // Coupon handling
  const applyCoupon = (code: string): { success: boolean; message: string } => {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) {
      return { success: false, message: 'يرجى إدخال رمز الكوبون أولاً' };
    }
    if (cleanCode === 'JOKER' || cleanCode === 'JOKER-YARIM' || cleanCode === 'YARIM2026') {
      setActiveCoupon({
        code: cleanCode,
        discountAmount: 1000,
        label: 'خصم ترويجي خاص بمركز الجوكر (1,000 ر.ي)',
      });
      return { success: true, message: 'تم تطبيق كود الخصم بنجاح! تم خصم 1,000 ر.ي' };
    }
    if (cleanCode === 'RAMADAN' || cleanCode === 'FRIENDS') {
      setActiveCoupon({
        code: cleanCode,
        discountAmount: 1500,
        label: 'كوبون دعوة الأصدقاء (1,500 ر.ي)',
      });
      return { success: true, message: 'تم تفعيل كوبون الأصدقاء بخصم 1,500 ر.ي!' };
    }
    return {
      success: false,
      message: 'كود الكوبون غير صحيح. يمكنك تجربة كود "JOKER" أو "FRIENDS"',
    };
  };

  const removeCoupon = () => {
    setActiveCoupon(null);
  };

  // Cart calculations
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartSubtotal = cart.reduce(
    (total, item) => total + item.product.price * item.quantity,
    0
  );
  const cartDiscount = activeCoupon ? Math.min(activeCoupon.discountAmount, cartSubtotal) : 0;
  const cartTotal = Math.max(0, cartSubtotal - cartDiscount);

  // Order placement
  const placeOrder = (orderInput: {
    customerName: string;
    phoneNumber: string;
    deliveryAddress: string;
    notes?: string;
    paymentMethod: 'cod' | 'kuraimi_onecash';
  }): CustomerOrder => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const orderId = `JKR-${randomNum}`;
    const now = new Date();
    const formattedDate = `${now.toLocaleDateString('ar-YE')} ${now.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' })}`;

    const newOrder: CustomerOrder = {
      id: orderId,
      customerName: orderInput.customerName,
      phoneNumber: orderInput.phoneNumber,
      deliveryAddress: orderInput.deliveryAddress,
      notes: orderInput.notes,
      paymentMethod: orderInput.paymentMethod,
      items: cart.map((item) => ({
        productId: item.product.id,
        productName: item.product.name,
        unit: item.product.unit,
        quantity: item.quantity,
        price: item.product.price,
        total: item.product.price * item.quantity,
      })),
      subtotal: cartSubtotal,
      discountAmount: cartDiscount,
      couponCode: activeCoupon?.code,
      total: cartTotal,
      createdAt: formattedDate,
      status: 'pending_whatsapp',
    };

    setOrders((prev) => [newOrder, ...prev]);
    setLastCompletedOrder(newOrder);
    clearCart();
    return newOrder;
  };

  // Admin actions
  const addProduct = (newProd: Omit<Product, 'id'>) => {
    const id = `prod-${Date.now()}`;
    const product: Product = { ...newProd, id };
    setProducts((prev) => [product, ...prev]);
  };

  const updateProduct = (id: string, updatedFields: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updatedFields } : item))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((item) => item.id !== id));
  };

  const resetProductsToDefault = () => {
    setProducts(INITIAL_PRODUCTS);
    localStorage.removeItem(LOCAL_STORAGE_PRODUCTS);
  };

  // Group deal join
  const joinGroupDeal = (dealId: string) => {
    setGroupDeals((prev) =>
      prev.map((deal) => {
        if (deal.id === dealId) {
          const nextCount = Math.min(deal.targetCount, deal.currentCount + 1);
          return { ...deal, currentCount: nextCount };
        }
        return deal;
      })
    );
  };

  return (
    <ShopContext.Provider
      value={{
        products,
        cart,
        orders,
        groupDeals,
        searchQuery,
        selectedCategory,
        selectedProduct,
        isCartOpen,
        isCheckoutOpen,
        isAdminOpen,
        isGroupBuyingOpen,
        isInviteModalOpen,
        activeCoupon,
        lastCompletedOrder,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        applyCoupon,
        removeCoupon,
        placeOrder,
        addProduct,
        updateProduct,
        deleteProduct,
        resetProductsToDefault,
        joinGroupDeal,
        setSearchQuery,
        setSelectedCategory,
        setSelectedProduct,
        setIsCartOpen,
        setIsCheckoutOpen,
        setIsAdminOpen,
        setIsGroupBuyingOpen,
        setIsInviteModalOpen,
        setLastCompletedOrder,
        cartCount,
        cartSubtotal,
        cartDiscount,
        cartTotal,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
