import { CartItem, CustomerOrder } from '../types';
import { STORE_CONFIG } from '../data/initialProducts';

/**
 * Format Yemeni Rial currency with commas and currency symbol
 */
export function formatCurrency(amount: number): string {
  const formatted = new Intl.NumberFormat('ar-YE', {
    maximumFractionDigits: 0,
  }).format(amount);
  return `${formatted} ${STORE_CONFIG.currency}`;
}

/**
 * Format plain number with commas
 */
export function formatNumber(num: number): string {
  return new Intl.NumberFormat('ar-YE').format(num);
}

/**
 * Calculate discount percentage
 */
export function calculateDiscount(original: number, current: number): number {
  if (original <= current || original <= 0) return 0;
  return Math.round(((original - current) / original) * 100);
}

/**
 * Build WhatsApp order link for full checkout cart
 */
export function buildWhatsAppOrderUrl(order: CustomerOrder): string {
  const lines: string[] = [
    `🛍️ *طلب شراء جديد من متجر إيديفيكس اليمن*`,
    `🏪 *${STORE_CONFIG.subName} - يريم*`,
    `📍 ${STORE_CONFIG.address}`,
    `----------------------------------------`,
    `📋 *بيانات العميل والتوصيل:*`,
    `👤 *الاسم:* ${order.customerName}`,
    `📞 *رقم الهاتف:* ${order.phoneNumber}`,
    `🏡 *عنوان التوصيل:* ${order.deliveryAddress}`,
  ];

  if (order.notes && order.notes.trim()) {
    lines.push(`📝 *ملاحظات الطلب:* ${order.notes.trim()}`);
  }

  lines.push(`----------------------------------------`);
  lines.push(`📦 *قائمة المنتجات المطلوبة:*`);

  order.items.forEach((item, index) => {
    lines.push(
      `${index + 1}. *${item.productName}* (${item.unit})\n   ▫️ الكمية: ${item.quantity} × ${formatCurrency(item.price)} = ${formatCurrency(item.total)}`
    );
  });

  lines.push(`----------------------------------------`);
  lines.push(`💵 *إجمالي المشتريات:* ${formatCurrency(order.subtotal)}`);

  if (order.discountAmount > 0) {
    lines.push(`🎁 *قيمة الخصم/الكوبون:* -${formatCurrency(order.discountAmount)}`);
  }

  lines.push(`🚚 *رسوم التوصيل (داخل يريم):* مجاناً / مع المندوب`);
  lines.push(`💰 *المبلغ الصافي المطلوب:* *${formatCurrency(order.total)}*`);
  lines.push(`----------------------------------------`);
  lines.push(`🔖 *رقم مرجع الطلب التجريبي:* ${order.id}`);
  lines.push(`⏰ *تاريخ الطلب:* ${order.createdAt}`);
  lines.push(`\nيرجى تأكيد الطلب وتحديد موعد الاستلام والتوصيل. شكراً لكم!`);

  const fullText = lines.join('\n');
  const encodedText = encodeURIComponent(fullText);

  return `https://wa.me/${STORE_CONFIG.whatsappInternational}?text=${encodedText}`;
}

/**
 * Build direct WhatsApp quick order for a single product
 */
export function buildSingleProductWhatsAppUrl(
  productName: string,
  price: number,
  quantity: number = 1
): string {
  const lines = [
    `مرحباً مركز الجوكر للتخفيضات (إيديفيكس اليمن - يريم 👋)`,
    `أرغب في الاستفسار والطلب السريع لهذا المنتج:`,
    `📦 *المنتج:* ${productName}`,
    `🔢 *الكمية:* ${quantity}`,
    `💵 *السعر:* ${formatCurrency(price * quantity)}`,
    `\nهل المنتج متوفر حالياً في فرعكم (يريم - شارع 20)؟ شكراً لك.`
  ];
  const encodedText = encodeURIComponent(lines.join('\n'));
  return `https://wa.me/${STORE_CONFIG.whatsappInternational}?text=${encodedText}`;
}

/**
 * Build Direct Call URL
 */
export function getDirectCallUrl(): string {
  return `tel:+${STORE_CONFIG.phoneCallInternational}`;
}
