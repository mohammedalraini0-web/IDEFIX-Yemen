import React from 'react';
import { 
  Home, 
  Layers, 
  Users, 
  ShoppingBag, 
  ShieldAlert, 
  PhoneCall, 
  MessageCircle 
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { STORE_CONFIG } from '../data/initialProducts';
import { getDirectCallUrl } from '../utils/formatters';

export const BottomNav: React.FC = () => {
  const { 
    cartCount, 
    setIsCartOpen, 
    setIsAdminOpen, 
    setIsGroupBuyingOpen, 
    setSelectedCategory 
  } = useShop();

  const quickWhatsAppUrl = `https://wa.me/${STORE_CONFIG.whatsappInternational}?text=${encodeURIComponent(
    'مرحباً مركز الجوكر للتخفيضات (إيديفيكس اليمن - يريم). أود الاستفسار عن توفر المنتجات والعروض.'
  )}`;

  return (
    <>
      {/* Floating Quick Action Buttons on mobile (WhatsApp + Call) */}
      <div className="fixed bottom-18 left-3 z-40 flex flex-col gap-2.5 sm:hidden">
        {/* Direct Call Button */}
        <a
          href={getDirectCallUrl()}
          className="w-11 h-11 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-600/40 active:scale-95 transition-transform"
          aria-label="اتصال هاتفي مباشر بفرع يريم"
        >
          <PhoneCall className="w-5 h-5" />
        </a>

        {/* Quick WhatsApp Button */}
        <a
          href={quickWhatsAppUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/40 active:scale-95 transition-transform"
          aria-label="مراسلة واتساب"
        >
          <MessageCircle className="w-6 h-6" />
        </a>
      </div>

      {/* Android Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-200 py-1.5 px-2 md:hidden shadow-lg safe-area-pb">
        <div className="flex items-center justify-around text-[10px] font-bold">
          {/* Home */}
          <button
            onClick={() => {
              setSelectedCategory('all');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex flex-col items-center gap-1 text-gray-600 hover:text-red-600 p-1"
          >
            <Home className="w-5 h-5" />
            <span>الرئيسية</span>
          </button>

          {/* Categories */}
          <button
            onClick={() => {
              const el = document.getElementById('categories-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="flex flex-col items-center gap-1 text-gray-600 hover:text-red-600 p-1"
          >
            <Layers className="w-5 h-5" />
            <span>الأقسام</span>
          </button>

          {/* Group Deals */}
          <button
            onClick={() => setIsGroupBuyingOpen(true)}
            className="flex flex-col items-center gap-1 text-gray-600 hover:text-red-600 p-1 relative"
          >
            <Users className="w-5 h-5 text-red-600" />
            <span className="text-red-600">شراء جماعي</span>
          </button>

          {/* Cart with Badge */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex flex-col items-center gap-1 text-gray-600 hover:text-red-600 p-1 relative"
          >
            <div className="relative">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-red-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <span>السلة</span>
          </button>

          {/* Admin */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="flex flex-col items-center gap-1 text-gray-600 hover:text-amber-700 p-1"
          >
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            <span>الإدارة</span>
          </button>
        </div>
      </nav>
    </>
  );
};
