import React, { useState } from 'react';
import { 
  X, 
  ShoppingBag, 
  MessageCircle, 
  PhoneCall, 
  Check, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  Minus, 
  Plus 
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { STORE_CONFIG } from '../data/initialProducts';
import { 
  formatCurrency, 
  calculateDiscount, 
  buildSingleProductWhatsAppUrl, 
  getDirectCallUrl 
} from '../utils/formatters';

export const ProductDetailsModal: React.FC = () => {
  const { selectedProduct, setSelectedProduct, addToCart, setIsCartOpen } = useShop();
  const [quantity, setQuantity] = useState(1);
  const [addedAnimation, setAddedAnimation] = useState(false);

  if (!selectedProduct) return null;

  const discountPercent = calculateDiscount(
    selectedProduct.originalPrice,
    selectedProduct.price
  );
  const totalSavings = (selectedProduct.originalPrice - selectedProduct.price) * quantity;
  const totalPrice = selectedProduct.price * quantity;

  const handleAddToCart = () => {
    addToCart(selectedProduct, quantity);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      setSelectedProduct(null);
      setIsCartOpen(true);
    }, 600);
  };

  const handleDirectWhatsApp = () => {
    const url = buildSingleProductWhatsAppUrl(
      selectedProduct.name,
      selectedProduct.price,
      quantity
    );
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Click outside backdrop */}
      <div 
        className="fixed inset-0" 
        onClick={() => setSelectedProduct(null)} 
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[92vh] flex flex-col border border-gray-100">
        {/* Header with close button */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100 bg-gray-50/70">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black text-white bg-red-600 px-2.5 py-1 rounded-full">
              تفاصيل المنتج
            </span>
            <span className="text-xs font-bold text-gray-500">
              {STORE_CONFIG.subName}
            </span>
          </div>

          <button
            onClick={() => setSelectedProduct(null)}
            className="p-1.5 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-200 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-5 no-scrollbar">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-start">
            {/* Image Preview & Badges */}
            <div className="relative w-full aspect-square rounded-2xl overflow-hidden bg-gray-100 border border-gray-200 shadow-xs">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full h-full object-cover"
              />
              {discountPercent > 0 && (
                <div className="absolute top-3 right-3 bg-red-600 text-white font-black text-xs px-2.5 py-1 rounded-xl shadow-md">
                  خصم {discountPercent}%
                </div>
              )}
              {selectedProduct.badge && (
                <div className="absolute top-3 left-3 bg-gray-900/80 backdrop-blur-md text-amber-300 font-bold text-xs px-2.5 py-1 rounded-xl">
                  {selectedProduct.badge}
                </div>
              )}
            </div>

            {/* Product Info */}
            <div className="space-y-4">
              <div>
                <span className="text-xs font-bold text-gray-500 bg-gray-100 px-2.5 py-0.5 rounded-md">
                  {selectedProduct.unit}
                </span>
                <h2 className="text-lg sm:text-xl font-black text-gray-900 mt-2 leading-snug">
                  {selectedProduct.name}
                </h2>
              </div>

              {/* Pricing breakdown */}
              <div className="bg-red-50/60 rounded-2xl p-3.5 border border-red-100 space-y-1.5">
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-black text-red-600">
                    {formatCurrency(totalPrice)}
                  </span>
                  {selectedProduct.originalPrice > selectedProduct.price && (
                    <span className="text-sm text-gray-400 line-through">
                      {formatCurrency(selectedProduct.originalPrice * quantity)}
                    </span>
                  )}
                </div>

                {totalSavings > 0 && (
                  <p className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>توفر مع مركز الجوكر: {formatCurrency(totalSavings)}</span>
                  </p>
                )}
              </div>

              {/* Stock status & Location */}
              <div className="space-y-1.5 text-xs text-gray-600">
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${selectedProduct.inStock ? 'bg-emerald-500' : 'bg-red-500'}`} />
                  <span className="font-bold text-gray-800">
                    {selectedProduct.inStock
                      ? `متوفر في المخزون (${selectedProduct.stockCount} قطعة متاحة)`
                      : 'نفذت الكمية حالياً'}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-gray-500">
                  <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                  <span>الموقع: {STORE_CONFIG.address}</span>
                </div>
              </div>

              {/* Quantity Selector */}
              {selectedProduct.inStock && (
                <div className="pt-2">
                  <label className="block text-xs font-bold text-gray-700 mb-1.5">
                    الكمية المطلوبة:
                  </label>
                  <div className="flex items-center gap-3">
                    <div className="inline-flex items-center border border-gray-300 rounded-xl bg-white shadow-2xs">
                      <button
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        className="p-2 text-gray-600 hover:text-red-600 hover:bg-gray-50 rounded-r-xl transition-colors"
                        disabled={quantity <= 1}
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-12 text-center font-black text-gray-900 text-sm">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity((q) => Math.min(selectedProduct.stockCount, q + 1))}
                        className="p-2 text-gray-600 hover:text-red-600 hover:bg-gray-50 rounded-l-xl transition-colors"
                        disabled={quantity >= selectedProduct.stockCount}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <span className="text-xs text-gray-500 font-medium">
                      ({selectedProduct.unit})
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Description Section */}
          <div className="border-t border-gray-100 pt-4">
            <h4 className="text-sm font-bold text-gray-900 mb-2">وصف المنتج ومميزاته:</h4>
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed bg-gray-50/80 p-3.5 rounded-2xl border border-gray-100">
              {selectedProduct.description}
            </p>
          </div>

          {/* Reassurance */}
          <div className="flex items-center gap-2 p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl text-xs text-emerald-800">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>منتج أصلي مضمون 100% | التوصيل داخل يريم خلال ساعات مع الدفع عند الاستلام</span>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-gray-50 border-t border-gray-200/80 flex flex-col sm:flex-row gap-2.5">
          {/* Add to cart */}
          <button
            onClick={handleAddToCart}
            disabled={!selectedProduct.inStock}
            className={`flex-1 py-3 px-4 rounded-xl text-sm font-black flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm ${
              !selectedProduct.inStock
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : addedAnimation
                ? 'bg-emerald-600 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-4 h-4" />
                <span>تمت الإضافة للسلة!</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4" />
                <span>أضف إلى السلة ({formatCurrency(totalPrice)})</span>
              </>
            )}
          </button>

          {/* Direct WhatsApp Quick Order */}
          <button
            onClick={handleDirectWhatsApp}
            className="flex-1 py-3 px-4 rounded-xl text-sm font-black bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center gap-2 transition-colors active:scale-95 shadow-sm"
          >
            <MessageCircle className="w-4 h-4" />
            <span>شراء فوري عبر واتساب</span>
          </button>

          {/* Call store button */}
          <a
            href={getDirectCallUrl()}
            className="sm:w-auto py-3 px-4 rounded-xl text-sm font-bold bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 flex items-center justify-center gap-1.5 transition-colors"
            title="اتصال هاتفي للاستفسار"
          >
            <PhoneCall className="w-4 h-4 text-red-600" />
            <span className="sm:hidden">اتصال</span>
          </a>
        </div>
      </div>
    </div>
  );
};
