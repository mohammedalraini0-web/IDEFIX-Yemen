import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  MessageCircle, 
  Gift, 
  Sparkles, 
  Info,
  Tag 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useShop } from '../context/ShopContext';
import { STORE_CONFIG } from '../data/initialProducts';

export const InviteFriendsModal: React.FC = () => {
  const { isInviteModalOpen, setIsInviteModalOpen, applyCoupon, setIsCartOpen } = useShop();
  const [copiedLink, setCopiedLink] = useState(false);
  const [appliedPromo, setAppliedPromo] = useState(false);

  if (!isInviteModalOpen) return null;

  const shareUrl = window.location.origin;
  const invitationMessage = `مرحباً! جرب تطبيق "إيديفيكس اليمن" لمركز الجوكر للتخفيضات في يريم (شارع 20). تخفيضات قوية على المواد الغذائية والمنظفات وتوصيل سريع. استخدم كود الخصم (FRIENDS) للحصول على خصم 1,500 ريال يمني:\n${shareUrl}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(invitationMessage);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleWhatsAppShare = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(invitationMessage)}`;
    window.open(url, '_blank');
  };

  const handleApplyGiftCoupon = () => {
    applyCoupon('FRIENDS');
    setAppliedPromo(true);
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#DC2626', '#10B981', '#F59E0B'],
      });
    } catch (e) {
      console.log(e);
    }
    setTimeout(() => {
      setIsInviteModalOpen(false);
      setIsCartOpen(true);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="fixed inset-0" 
        onClick={() => setIsInviteModalOpen(false)} 
      />

      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-gray-100 p-6 sm:p-7 space-y-4 animate-in zoom-in-95 duration-200">
        <button
          onClick={() => setIsInviteModalOpen(false)}
          className="absolute top-4 left-4 p-1.5 rounded-full text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Demo Warning Pill */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5 flex items-center gap-2 text-xs text-amber-800">
          <Info className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="font-bold">
            ميزة تجريبية Demo: برنامج المكافآت ودعوة الأصدقاء في يريم
          </span>
        </div>

        {/* Header Icon */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-red-600 to-rose-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-red-600/20">
            <Gift className="w-8 h-8 text-amber-300" />
          </div>
          <h3 className="text-xl font-black text-gray-900">
            شارك التطبيق مع أصدقائك في يريم
          </h3>
          <p className="text-xs sm:text-sm text-gray-500 leading-relaxed max-w-sm mx-auto">
            احصل أنت وصديقك على قسيمة شراء بقيمة <strong>1,500 ر.ي</strong> عند دعوة معارفك للتسوق من مركز الجوكر.
          </p>
        </div>

        {/* Coupon Card */}
        <div className="bg-red-50/70 border border-dashed border-red-300 rounded-2xl p-4 text-center space-y-2">
          <div className="text-xs font-bold text-gray-500 flex items-center justify-center gap-1">
            <Tag className="w-3.5 h-3.5 text-red-600" />
            <span>كوبون الهدية الحصري:</span>
          </div>
          <div className="font-mono text-2xl font-black text-red-600 tracking-wider">
            FRIENDS
          </div>
          <p className="text-[11px] text-gray-500">
            يمنحك خصم 1,500 ريال يمني فوري على سلة التسوق
          </p>

          <button
            onClick={handleApplyGiftCoupon}
            disabled={appliedPromo}
            className="mt-1 w-full py-2 px-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
          >
            {appliedPromo ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>تم تطبيق الكوبون في سلتك!</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>تطبيق الكوبون على سلة مشترياتي فوراً</span>
              </>
            )}
          </button>
        </div>

        {/* Share buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={handleWhatsAppShare}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>مشاركة الدعوة عبر واتساب</span>
          </button>

          <button
            onClick={handleCopyLink}
            className="w-full py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors border border-gray-200"
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">تم نسخ نص ورابط الدعوة!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-gray-500" />
                <span>نسخ رابط الدعوة للمشاركة</span>
              </>
            )}
          </button>
        </div>

        <p className="text-[11px] text-center text-gray-400">
          العرض ساري لسكان مدينة يريم ومحافظة إب - مركز الجوكر للتخفيضات
        </p>
      </div>
    </div>
  );
};
