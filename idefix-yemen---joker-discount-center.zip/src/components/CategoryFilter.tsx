import React from 'react';
import { 
  Layers, 
  ShoppingBag, 
  Sparkles, 
  HeartHandshake, 
  UtensilsCrossed, 
  Home 
} from 'lucide-react';
import { CATEGORIES } from '../data/initialProducts';
import { useShop } from '../context/ShopContext';
import { CategoryId } from '../types';

export const CategoryFilter: React.FC = () => {
  const { selectedCategory, setSelectedCategory, products } = useShop();

  const getIcon = (id: CategoryId) => {
    switch (id) {
      case 'groceries':
        return <ShoppingBag className="w-4 h-4" />;
      case 'cleaning':
        return <Sparkles className="w-4 h-4" />;
      case 'personal_care':
        return <HeartHandshake className="w-4 h-4" />;
      case 'kitchen':
        return <UtensilsCrossed className="w-4 h-4" />;
      case 'household':
        return <Home className="w-4 h-4" />;
      default:
        return <Layers className="w-4 h-4" />;
    }
  };

  const getProductCount = (catId: CategoryId) => {
    if (catId === 'all') return products.length;
    return products.filter((p) => p.category === catId).length;
  };

  const allCategoryList = [
    { id: 'all' as CategoryId, name: 'جميع الأقسام' },
    ...CATEGORIES,
  ];

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between">
        <h2 className="text-base sm:text-lg font-black text-gray-900 flex items-center gap-2">
          <span>أقسام مركز الجوكر</span>
          <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-full">
            تخفيضات يريم
          </span>
        </h2>
      </div>

      {/* Horizontal scrollable category pill list */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 no-scrollbar">
        {allCategoryList.map((cat) => {
          const isActive = selectedCategory === cat.id;
          const count = getProductCount(cat.id);

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 border shrink-0 ${
                isActive
                  ? 'bg-red-600 text-white border-red-600 shadow-sm shadow-red-500/20 scale-[1.02]'
                  : 'bg-white text-gray-700 hover:text-red-600 hover:bg-red-50/50 border-gray-200 shadow-2xs'
              }`}
            >
              <span className={isActive ? 'text-white' : 'text-red-500'}>
                {getIcon(cat.id)}
              </span>
              <span>{cat.name}</span>
              <span
                className={`text-[11px] px-1.5 py-0.2 rounded-full font-bold ${
                  isActive ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-500'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
