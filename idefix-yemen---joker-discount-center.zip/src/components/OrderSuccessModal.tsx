import React from 'react';
import { 
  CheckCircle2, 
  MessageCircle, 
  PhoneCall, 
  MapPin, 
  Receipt, 
  X, 
  ArrowRight 
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { STORE_CONFIG } from '../data/initialProducts';
import { formatCurrency, buildWhatsAppOrderUrl, getDirectCallUrl } from '../utils/formatters';

export const OrderSuccessModal: React.FC = () => {
  const { lastCompletedOrder, setLastCompletedOrder } = useShop();

  if (!lastCompletedOrder) return null;

  const whatsappUrl = buildWhatsAppOrderUrl(lastCompletedOrder);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="fixed inset-0" 
        onClick={() => setLastCompletedOrder(null)} 
      />

      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden z-10 border border-gray-100 p-6 sm:p-8 text-center space-y-5 animate-in zoom-in-95 duration-200">
        <button
          onClick={() => setLastCompletedOrder(null)}
          className="absolute top-4 left-4 p-1 rounded-full text-gray-400 hover:text-gray-600 transition-colors"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-emerald-100 text-emerald-600 rounded-full mx-auto flex items-center justify-center shadow-inner">
          <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12" />
        </div>

        {/* Title & confirmation */}
        <div className="space-y-1">
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            تم تجهيز رسالة الطلب بنجاح
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-gray-900 mt-2">
            شكراً لطلبك من مركز الجوكر!
          </h2>
          <p className="text-xs sm:text-sm text-gray-600 max-w-sm mx-auto leading-relaxed">
            مرحباً بك يا <strong>{lastCompletedOrder.customerName}</strong>، تم إعداد تفاصيل مشترياتك للتأكيد مع خدمة العملاء في يريم.
          </p>
        </div>

        {/* Order Summary Box */}
        <div className="bg-gray-50 rounded-2xl p-4 text-xs space-y-2 border border-gray-100 text-right">
          <div className="flex justify-between items-center pb-2 border-b border-gray-200">
            <span className="font-bold text-gray-500 flex items-center gap-1">
              <Receipt className="w-3.5 h-3.5" />
              <span>رقم مرجع الطلب:</span>
            </span>
            <span className="font-mono font-black text-gray-900 text-sm">
              #{lastCompletedOrder.id}
            </span>
          </div>

          <div className="flex justify-between text-gray-600">
            <span>العنوان المسجل:</span>
            <span className="font-semibold text-gray-800 truncate max-w-[200px]">
              {lastCompletedOrder.deliveryAddress}
            </span>
          </div>

          <div className="flex justify-between text-gray-600">
            <span>المبلغ الإجمالي المطلوب:</span>
            <span className="font-black text-red-600 text-sm">
              {formatCurrency(lastCompletedOrder.total)}
            </span>
          </div>

          <div className="flex justify-between text-gray-500 text-[11px] pt-1">
            <span>طريقة الدفع:</span>
            <span className="font-medium">
              {lastCompletedOrder.paymentMethod === 'cod' ? 'الدفع عند الاستلام نقداً' : 'تحويل الكريمي / ون كاش'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5 pt-2">
          {/* Re-open WhatsApp */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>فتح محادثة واتساب لإرسال الطلب الآن</span>
          </a>

          {/* Call store button */}
          <a
            href={getDirectCallUrl()}
            className="w-full py-2.5 bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <PhoneCall className="w-3.5 h-3.5 text-red-600" />
            <span>اتصال بفرع يريم للاستفسار: {STORE_CONFIG.phoneCallRaw}</span>
          </a>

          {/* Continue shopping */}
          <button
            onClick={() => setLastCompletedOrder(null)}
            className="text-xs font-bold text-red-600 hover:text-red-700 py-1 transition-colors flex items-center justify-center gap-1 mx-auto"
          >
            <span>مواصلة تصفح منتجات المركز</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* Address note */}
        <div className="text-[11px] text-gray-400 flex items-center justify-center gap-1 pt-1">
          <MapPin className="w-3.5 h-3.5 text-red-500" />
          <span>{STORE_CONFIG.address}</span>
        </div>
      </div>
    </div>
  );
};
