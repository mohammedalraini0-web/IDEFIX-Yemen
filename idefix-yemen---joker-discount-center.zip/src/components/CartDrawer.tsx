import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowLeft, 
  Tag, 
  Truck, 
  ShieldCheck, 
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { formatCurrency } from '../utils/formatters';

export const CartDrawer: React.FC = () => {
  const { 
    isCartOpen, 
    setIsCartOpen, 
    cart, 
    updateCartQuantity, 
    removeFromCart, 
    clearCart,
    cartSubtotal,
    cartDiscount,
    cartTotal,
    activeCoupon,
    applyCoupon,
    removeCoupon,
    setIsCheckoutOpen
  } = useShop();

  const [couponInput, setCouponInput] = useState('');
  const [couponFeedback, setCouponFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const result = applyCoupon(couponInput);
    if (result.success) {
      setCouponFeedback({ type: 'success', message: result.message });
      setCouponInput('');
    } else {
      setCouponFeedback({ type: 'error', message: result.message });
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Backdrop */}
      <div 
        className="fixed inset-0" 
        onClick={() => setIsCartOpen(false)} 
      />

      {/* Slide-over Drawer */}
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-red-600 text-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-amber-300" />
            <h2 className="font-black text-base sm:text-lg">سلة التسوق</h2>
            <span className="bg-white/20 text-white text-xs px-2 py-0.5 rounded-full font-bold">
              {cart.length} منتجات
            </span>
          </div>

          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="إغلاق السلة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Items or Empty state */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-20 h-20 rounded-full bg-red-50 text-red-500 flex items-center justify-center">
                <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
              </div>
              <div>
                <h3 className="font-extrabold text-gray-900 text-base">سلة التسوق فارغة حالياً</h3>
                <p className="text-xs text-gray-500 mt-1 max-w-xs leading-relaxed">
                  تصفح منتجات مركز الجوكر في يريم وأضف المواد الغذائية والمنظفات بأسعار التخفيض المميزة.
                </p>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-xs transition-colors"
              >
                تصفح العروض الآن
              </button>
            </div>
          ) : (
            <>
              {/* Item cards */}
              <div className="space-y-2.5">
                {cart.map((item) => (
                  <div
                    key={item.product.id}
                    className="p-3 bg-gray-50/80 rounded-2xl border border-gray-100 flex gap-3 items-center"
                  >
                    {/* Thumbnail */}
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-xl object-cover border border-gray-200 shrink-0 bg-white"
                    />

                    {/* Details */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-bold text-xs text-gray-900 truncate">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-gray-400 hover:text-red-600 transition-colors p-0.5"
                          title="حذف من السلة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[11px] text-gray-500 font-medium">
                        {item.product.unit} | {formatCurrency(item.product.price)}
                      </div>

                      {/* Quantity control */}
                      <div className="flex items-center justify-between pt-1">
                        <div className="inline-flex items-center border border-gray-200 rounded-lg bg-white shadow-2xs">
                          <button
                            onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                            className="p-1 text-gray-600 hover:text-red-600 transition-colors"
                            title="إنقاص"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-7 text-center font-bold text-xs text-gray-800">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                            className="p-1 text-gray-600 hover:text-red-600 transition-colors"
                            title="زيادة"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Line total */}
                        <span className="font-black text-xs text-red-600">
                          {formatCurrency(item.product.price * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Clear cart action */}
              <div className="flex justify-end pt-1">
                <button
                  onClick={clearCart}
                  className="text-[11px] font-bold text-gray-400 hover:text-red-600 transition-colors flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>تفريغ السلة بالكامل</span>
                </button>
              </div>

              {/* Coupon Form */}
              <div className="mt-4 pt-3 border-t border-gray-100">
                <label className="block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-red-600" />
                  <span>هل لديك كوبون خصم؟</span>
                </label>

                {activeCoupon ? (
                  <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
                    <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>{activeCoupon.label}</span>
                    </div>
                    <button
                      onClick={removeCoupon}
                      className="text-red-500 hover:text-red-700 font-bold text-xs underline"
                    >
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="جرب كود: JOKER أو FRIENDS"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      className="flex-1 bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-1.5 text-xs text-gray-800 outline-none uppercase"
                    />
                    <button
                      type="submit"
                      className="bg-gray-800 hover:bg-gray-900 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition-colors"
                    >
                      تطبيق
                    </button>
                  </form>
                )}

                {couponFeedback && !activeCoupon && (
                  <p
                    className={`text-[11px] font-medium mt-1.5 flex items-center gap-1 ${
                      couponFeedback.type === 'success' ? 'text-emerald-600' : 'text-red-500'
                    }`}
                  >
                    <AlertCircle className="w-3 h-3" />
                    <span>{couponFeedback.message}</span>
                  </p>
                )}
              </div>

              {/* Delivery notice */}
              <div className="bg-red-50/70 p-2.5 rounded-xl border border-red-100 text-[11px] text-red-800 flex items-center gap-2">
                <Truck className="w-4 h-4 text-red-600 shrink-0" />
                <span>توصيل مباشر إلى شارع 20 وكافة أحياء يريم فور تأكيد الطلب</span>
              </div>
            </>
          )}
        </div>

        {/* Footer with Calculations & Checkout Button */}
        {cart.length > 0 && (
          <div className="p-4 bg-gray-50 border-t border-gray-200/80 space-y-3">
            {/* Calculation rows */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-gray-600">
                <span>المجموع الفرعي:</span>
                <span className="font-bold">{formatCurrency(cartSubtotal)}</span>
              </div>

              {cartDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>خصم الكوبون:</span>
                  </span>
                  <span>-{formatCurrency(cartDiscount)}</span>
                </div>
              )}

              <div className="flex justify-between text-gray-600">
                <span>رسوم التوصيل (داخل يريم):</span>
                <span className="font-bold text-emerald-600">مجاناً</span>
              </div>

              <div className="pt-2 border-t border-gray-200 flex justify-between items-baseline text-sm font-black text-gray-900">
                <span>المبلغ الإجمالي النهائي:</span>
                <span className="text-xl text-red-600 font-black">
                  {formatCurrency(cartTotal)}
                </span>
              </div>
            </div>

            {/* Checkout Action Button */}
            <button
              onClick={handleProceedToCheckout}
              className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-black text-sm rounded-2xl shadow-lg shadow-red-600/25 flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <span>متابعة إتمام الطلب</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
