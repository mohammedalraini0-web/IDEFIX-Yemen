import React from 'react';
import { 
  MapPin, 
  Phone, 
  MessageCircle, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { STORE_CONFIG } from '../data/initialProducts';
import { getDirectCallUrl } from '../utils/formatters';

export const Footer: React.FC = () => {
  const whatsappUrl = `https://wa.me/${STORE_CONFIG.whatsappInternational}`;

  return (
    <footer className="bg-gray-900 text-gray-300 pt-10 pb-20 md:pb-10 border-t border-red-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Store Branding & Intro */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center font-black text-xl shadow-md">
                J
              </div>
              <div>
                <h3 className="font-black text-lg text-white">
                  IDEFIX Yemen | إيديفيكس اليمن
                </h3>
                <p className="text-xs text-red-400 font-bold">
                  {STORE_CONFIG.subName} - يريم
                </p>
              </div>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              مركزكم الأول للتخفيضات الحقيقية في مدينة يريم. نوفر المواد الغذائية والمؤن والمنظفات والأجهزة المنزلية بأفضل أسعار الجملة بالريال اليمني.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400 pt-1">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>أسعار مخفضة ومضمونة 100%</span>
            </div>
          </div>

          {/* Col 2: Store Location & Hours */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-gray-800 pb-2">
              موقع الفرع وأوقات العمل
            </h4>
            <div className="space-y-2.5 text-xs text-gray-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span className="leading-relaxed text-gray-200">
                  {STORE_CONFIG.address}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>يومياً: من 7:30 صباحاً حتى 11:30 مساءً</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>خدمة التوصيل السريع داخل يريم وضواحيها</span>
              </div>
            </div>
          </div>

          {/* Col 3: Direct Contacts & WhatsApp */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-gray-800 pb-2">
              الاتصال والطلبات المباشرة
            </h4>
            <div className="space-y-2.5 text-xs">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2 rounded-xl bg-gray-800/80 hover:bg-emerald-950/40 text-emerald-300 transition-colors border border-emerald-900/30"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>واتساب للطلبات: <strong>{STORE_CONFIG.whatsappRaw}</strong></span>
              </a>

              <a
                href={getDirectCallUrl()}
                className="flex items-center gap-2 p-2 rounded-xl bg-gray-800/80 hover:bg-red-950/40 text-red-300 transition-colors border border-red-900/30"
              >
                <Phone className="w-4 h-4 text-red-400" />
                <span>اتصال هاتفي مباشر: <strong>{STORE_CONFIG.phoneCallRaw}</strong></span>
              </a>

              <p className="text-[11px] text-gray-400">
                الدفع عند الاستلام نقداً في يريم أو عبر الكريمي / ون كاش.
              </p>
            </div>
          </div>

          {/* Col 4: Android & Technical Info */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white border-b border-gray-800 pb-2 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-red-400" />
              <span>جاهزية تطبيق أندرويد</span>
            </h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              تطبيق ويب متجاوب بالكامل مع الشاشات اللمسية وتجربة مستخدم مخصصة للهواتف الذكية مع إمكانية تحزيمه كـ APK أو PWA لأجهزة أندرويد.
            </p>
            <div className="p-2.5 rounded-xl bg-gray-800/60 border border-gray-700/60 text-[11px] text-gray-300">
              <span className="font-bold text-white">العملة المعتمدة:</span> الريال اليمني (YER)
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-gray-800 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 gap-3">
          <p>
            جميع الحقوق محفوظة &copy; {new Date().getFullYear()} إيديفيكس اليمن - مركز الجوكر للتخفيضات (يريم، شارع 20).
          </p>
          <div className="flex items-center gap-2 text-gray-400 text-[11px]">
            <span>تصميم أحمر وأبيض عصري</span>
            <span>•</span>
            <span>واجهة عربية كاملة RTL</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
