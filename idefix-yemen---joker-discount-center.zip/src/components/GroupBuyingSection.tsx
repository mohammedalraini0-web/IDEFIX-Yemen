import React, { useState } from 'react';
import { 
  Users, 
  Sparkles, 
  Clock, 
  MapPin, 
  ShoppingBag, 
  Check, 
  X, 
  Info,
  BadgePercent
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useShop } from '../context/ShopContext';
import { formatCurrency } from '../utils/formatters';

interface GroupBuyingSectionProps {
  isModal?: boolean;
}

export const GroupBuyingSection: React.FC<GroupBuyingSectionProps> = ({ isModal = false }) => {
  const { 
    groupDeals, 
    joinGroupDeal, 
    isGroupBuyingOpen, 
    setIsGroupBuyingOpen,
    addToCart,
    products
  } = useShop();

  const [joinedDealIds, setJoinedDealIds] = useState<{ [key: string]: boolean }>({});

  if (isModal && !isGroupBuyingOpen) return null;

  const handleJoinDeal = (dealId: string, productName: string, groupPrice: number) => {
    joinGroupDeal(dealId);
    setJoinedDealIds((prev) => ({ ...prev, [dealId]: true }));

    // Find product to add to cart at group price
    const matchedProduct = products.find((p) => p.name.includes(productName.split(' ')[0]));
    if (matchedProduct) {
      addToCart({
        ...matchedProduct,
        price: groupPrice,
        badge: 'سعر الشراء الجماعي',
      }, 1);
    }

    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#EF4444', '#10B981', '#3B82F6'],
      });
    } catch (e) {
      console.log(e);
    }
  };

  const content = (
    <div className="space-y-4">
      {/* Demo Announcement Pill */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 flex items-start gap-2.5 text-xs text-amber-900">
        <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="font-bold">
            ميزة تجريبية تفاعلية: الشراء الجماعي مع جيرانك في يريم (Group Buying Demo)
          </p>
          <p className="text-[11px] text-amber-800 leading-relaxed">
            تتيح هذه الميزة لسكان شارع 20 وحارات يريم التجمع في صفقة واحدة للمؤن والسلع الأساسية (سكر، أرز، زيت) للحصول على خصم إضافي يصل إلى 20%. جرب الانضمام أدناه!
          </p>
        </div>
      </div>

      {/* Grid of group deals */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {groupDeals.map((deal) => {
          const isJoined = joinedDealIds[deal.id];
          const isComplete = deal.currentCount >= deal.targetCount;
          const percentage = Math.min(100, Math.round((deal.currentCount / deal.targetCount) * 100));

          return (
            <div
              key={deal.id}
              className="bg-white rounded-2xl border border-red-100 hover:border-red-300 shadow-xs hover:shadow-md transition-all p-4 flex flex-col justify-between space-y-3 relative overflow-hidden"
            >
              {/* Top tag */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-black bg-red-600 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                  <BadgePercent className="w-3 h-3" />
                  <span>وفر {deal.savingsPercentage}% إضافي</span>
                </span>

                <div className="flex items-center gap-1 text-[11px] font-semibold text-gray-500">
                  <Clock className="w-3 h-3 text-red-500" />
                  <span>متبقي {deal.expiresInHours} ساعات</span>
                </div>
              </div>

              {/* Product preview */}
              <div className="flex gap-3 items-center">
                <img
                  src={deal.image}
                  alt={deal.productName}
                  className="w-16 h-16 rounded-xl object-cover border border-gray-100 bg-gray-50 shrink-0"
                />
                <div className="min-w-0">
                  <h4 className="font-bold text-xs sm:text-sm text-gray-900 leading-tight">
                    {deal.title}
                  </h4>
                  <p className="text-[11px] text-gray-500 flex items-center gap-1 mt-1 truncate">
                    <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                    <span>متاح لأهالي: {deal.neighborhood}</span>
                  </p>
                </div>
              </div>

              {/* Pricing comparison */}
              <div className="flex items-baseline justify-between bg-red-50/60 p-2.5 rounded-xl border border-red-100/80">
                <div>
                  <span className="text-xs text-gray-500">سعر المجموعة المخفض:</span>
                  <div className="text-base font-black text-red-600">
                    {formatCurrency(deal.groupPrice)}
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-[11px] text-gray-400 line-through">
                    {formatCurrency(deal.regularPrice)}
                  </span>
                  <div className="text-[11px] font-bold text-emerald-700">
                    توفير {formatCurrency(deal.regularPrice - deal.groupPrice)}
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-bold text-gray-700">
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-red-600" />
                    <span>المشاركون حتى الآن:</span>
                  </span>
                  <span>
                    {deal.currentCount} من {deal.targetCount} أشخاص
                  </span>
                </div>

                <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-red-600 to-rose-500 transition-all duration-500 rounded-full"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>

              {/* Join Button */}
              <button
                onClick={() => handleJoinDeal(deal.id, deal.productName, deal.groupPrice)}
                disabled={isJoined || isComplete}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all active:scale-95 ${
                  isJoined
                    ? 'bg-emerald-600 text-white cursor-default'
                    : isComplete
                    ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                    : 'bg-red-600 hover:bg-red-700 text-white shadow-xs'
                }`}
              >
                {isJoined ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>تم الانضمام وإضافة السلعة للسلة بالسعر الجماعي!</span>
                  </>
                ) : isComplete ? (
                  <span>اكتملت المجموعة بنجاح</span>
                ) : (
                  <>
                    <Users className="w-4 h-4" />
                    <span>انضم للصفقة الجماعية الآن (تجريبي)</span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
        <div 
          className="fixed inset-0" 
          onClick={() => setIsGroupBuyingOpen(false)} 
        />
        <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col border border-gray-100">
          <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-red-600 text-white">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-300" />
              <div>
                <h3 className="font-black text-base sm:text-lg">صفقات الشراء الجماعي (يريم)</h3>
                <p className="text-xs text-red-100">ميزة تجريبية لتخفيض أسعار المؤن مع الجيران</p>
              </div>
            </div>
            <button
              onClick={() => setIsGroupBuyingOpen(false)}
              className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="overflow-y-auto p-4 sm:p-6 no-scrollbar">
            {content}
          </div>
        </div>
      </div>
    );
  }

  return (
    <section className="bg-gradient-to-b from-red-50/50 to-white rounded-3xl p-4 sm:p-6 border border-red-100/80 shadow-2xs space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-red-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-black text-gray-900 text-base sm:text-lg">
              عروض الشراء الجماعي في يريم
            </h3>
            <p className="text-xs text-gray-500">
              اشترك مع جيرانك في شارع 20 واحصل على تخفيضات إضافية
            </p>
          </div>
        </div>

        <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2.5 py-1 rounded-full border border-amber-200">
          ميزة تجريبية Demo
        </span>
      </div>

      {content}
    </section>
  );
};
