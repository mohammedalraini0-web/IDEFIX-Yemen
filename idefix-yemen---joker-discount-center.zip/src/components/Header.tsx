import React from 'react';
import { 
  ShoppingBag, 
  Phone, 
  MapPin, 
  Search, 
  Users, 
  Share2, 
  ShieldAlert,
  Sparkles,
  X
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { STORE_CONFIG } from '../data/initialProducts';
import { getDirectCallUrl } from '../utils/formatters';

export const Header: React.FC = () => {
  const { 
    cartCount, 
    setIsCartOpen, 
    searchQuery, 
    setSearchQuery, 
    setIsAdminOpen,
    setIsGroupBuyingOpen,
    setIsInviteModalOpen
  } = useShop();

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-red-100 shadow-xs">
      {/* Top micro bar with Yarim address and quick call */}
      <div className="bg-gradient-to-r from-red-700 via-red-600 to-red-800 text-white text-xs py-1.5 px-3 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Store location */}
          <div className="flex items-center gap-1.5 font-medium truncate">
            <MapPin className="w-3.5 h-3.5 text-red-200 shrink-0 animate-bounce" />
            <span className="truncate">
              {STORE_CONFIG.address}
            </span>
          </div>

          {/* Quick contact buttons */}
          <div className="flex items-center gap-3">
            <a 
              href={getDirectCallUrl()} 
              className="flex items-center gap-1 hover:text-red-200 font-bold transition-colors bg-white/10 hover:bg-white/20 px-2 py-0.5 rounded-full"
              title="اتصال هاتفي مباشر"
            >
              <Phone className="w-3 h-3 text-green-300" />
              <span>اتصال مباشر: {STORE_CONFIG.phoneCallRaw}</span>
            </a>
            <span className="hidden md:inline text-red-200/60">|</span>
            <span className="hidden md:inline text-red-100 font-medium">
              واتساب للطلبات: {STORE_CONFIG.whatsappRaw}
            </span>
          </div>
        </div>
      </div>

      {/* Main navigation & branding */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-3">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-red-600 to-red-500 text-white flex items-center justify-center font-black text-xl shadow-md shadow-red-500/20 ring-2 ring-red-100">
              J
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-lg sm:text-xl text-gray-900 tracking-tight">IDEFIX</span>
                <span className="text-xs font-bold px-1.5 py-0.5 rounded-md bg-red-600 text-white">اليمن</span>
              </div>
              <p className="text-[11px] sm:text-xs font-semibold text-red-600">
                {STORE_CONFIG.subName} - يريم
              </p>
            </div>
          </div>

          {/* Search bar on desktop */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="ابحث عن منتج (سكر، أرز، زيت، مسحوق غسيل، خلاط...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-gray-100/90 hover:bg-gray-100 focus:bg-white border border-gray-200 focus:border-red-500 rounded-full py-2 pr-10 pl-9 text-sm text-gray-800 placeholder-gray-400 outline-none transition-all focus:ring-2 focus:ring-red-100"
              />
              <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-0.5"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Action tools */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Group Buying demo button */}
            <button
              onClick={() => setIsGroupBuyingOpen(true)}
              className="hidden lg:flex items-center gap-1 text-xs font-bold text-gray-700 hover:text-red-600 bg-red-50/80 hover:bg-red-100 px-2.5 py-1.5 rounded-lg border border-red-200/60 transition-colors"
              title="صفقات الشراء الجماعي"
            >
              <Users className="w-3.5 h-3.5 text-red-600" />
              <span>شراء جماعي</span>
              <span className="bg-red-600 text-white text-[10px] px-1 rounded-full font-bold">تجريبي</span>
            </button>

            {/* Invite Friends demo button */}
            <button
              onClick={() => setIsInviteModalOpen(true)}
              className="hidden sm:flex items-center gap-1 text-xs font-bold text-gray-700 hover:text-red-600 bg-gray-100 hover:bg-gray-200/80 px-2.5 py-1.5 rounded-lg border border-gray-200 transition-colors"
              title="دعوة الأصدقاء وكوبونات الخصم"
            >
              <Share2 className="w-3.5 h-3.5 text-red-600" />
              <span>دعوة الأصدقاء</span>
            </button>

            {/* Admin Prototype button */}
            <button
              onClick={() => setIsAdminOpen(true)}
              className="flex items-center gap-1 text-xs font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-300 px-2.5 py-1.5 rounded-lg transition-colors"
              title="لوحة الإدارة التجريبية"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">لوحة الإدارة</span>
              <span className="text-[10px] bg-amber-200 text-amber-900 px-1 rounded">تجريبي</span>
            </button>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white px-3 sm:px-4 py-2 rounded-xl font-bold text-sm shadow-sm hover:shadow transition-all active:scale-95"
              aria-label="سلة التسوق"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">السلة</span>
              {cartCount > 0 && (
                <span className="bg-white text-red-600 text-xs font-black min-w-5 h-5 px-1 rounded-full flex items-center justify-center shadow-xs">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile search bar */}
        <div className="md:hidden mt-2.5">
          <div className="relative w-full">
            <input
              type="text"
              placeholder="ابحث في مركز الجوكر (سكر، أرز، زيت...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-100 focus:bg-white border border-gray-200 focus:border-red-500 rounded-xl py-2 pr-9 pl-9 text-xs text-gray-800 placeholder-gray-400 outline-none transition-all"
            />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
