import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed top-12 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-amber-600 text-white px-4 py-2 rounded-full shadow-lg text-xs font-bold animate-bounce border border-amber-400">
      <WifiOff className="w-4 h-4" />
      <span>وضع عدم الاتصال: يمكنك تصفح المنتجات المحفوظة محلياً</span>
    </div>
  );
};
