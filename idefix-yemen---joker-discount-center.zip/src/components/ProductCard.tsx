import React, { useState } from 'react';
import { 
  ShoppingBag, 
  MessageCircle, 
  Check, 
  CheckCircle2, 
  XCircle, 
  Eye, 
  Sparkles 
} from 'lucide-react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';
import { formatCurrency, calculateDiscount, buildSingleProductWhatsAppUrl } from '../utils/formatters';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, setSelectedProduct, cart } = useShop();
  const [justAdded, setJustAdded] = useState(false);

  const cartItem = cart.find((item) => item.product.id === product.id);
  const discountPercent = calculateDiscount(product.originalPrice, product.price);
  const savingsAmount = product.originalPrice - product.price;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock) return;
    addToCart(product, 1);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1200);
  };

  const handleWhatsAppQuickOrder = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = buildSingleProductWhatsAppUrl(product.name, product.price, 1);
    window.open(url, '_blank');
  };

  return (
    <div
      onClick={() => setSelectedProduct(product)}
      className="group relative bg-white rounded-2xl border border-gray-200/80 hover:border-red-300 shadow-2xs hover:shadow-lg hover:shadow-red-500/5 transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer"
    >
      {/* Top Image area */}
      <div className="relative w-full aspect-square bg-gray-100 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Floating Discount Badge */}
        {discountPercent > 0 && (
          <div className="absolute top-2.5 right-2.5 bg-red-600 text-white text-[11px] font-black px-2 py-1 rounded-lg shadow-md flex items-center gap-0.5">
            <span>خصم {discountPercent}%</span>
          </div>
        )}

        {/* Custom store badge if exists */}
        {product.badge && (
          <div className="absolute top-2.5 left-2.5 bg-gray-900/80 backdrop-blur-md text-amber-300 text-[10px] font-extrabold px-2 py-0.5 rounded-md flex items-center gap-1 shadow-sm">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>{product.badge}</span>
          </div>
        )}

        {/* In Stock / Out of Stock pill */}
        <div className="absolute bottom-2 right-2">
          {product.inStock ? (
            <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-white/90 backdrop-blur-md text-emerald-700 px-2 py-0.5 rounded-full shadow-2xs border border-emerald-100">
              <CheckCircle2 className="w-3 h-3 text-emerald-500" />
              <span>متوفر بـ يريم ({product.stockCount})</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-white/90 backdrop-blur-md text-red-600 px-2 py-0.5 rounded-full shadow-2xs border border-red-100">
              <XCircle className="w-3 h-3 text-red-500" />
              <span>نفذت الكمية</span>
            </span>
          )}
        </div>

        {/* Quick View Hover Overlay on desktop */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="bg-white/90 backdrop-blur-md text-gray-800 text-xs font-bold px-3 py-1.5 rounded-full shadow-md flex items-center gap-1">
            <Eye className="w-3.5 h-3.5 text-red-600" />
            <span>عرض التفاصيل</span>
          </span>
        </div>
      </div>

      {/* Content area */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          {/* Unit / Pack label */}
          <div className="flex items-center justify-between text-[11px] font-semibold text-gray-500 mb-1">
            <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded">
              {product.unit}
            </span>
            {savingsAmount > 0 && (
              <span className="text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded text-[10px]">
                توفير {formatCurrency(savingsAmount)}
              </span>
            )}
          </div>

          {/* Product Title */}
          <h3 className="font-bold text-gray-900 text-sm sm:text-base leading-snug line-clamp-2 group-hover:text-red-600 transition-colors">
            {product.name}
          </h3>

          {/* Brief description snippet */}
          <p className="text-xs text-gray-500 line-clamp-1 mt-1">
            {product.description}
          </p>
        </div>

        {/* Pricing */}
        <div className="pt-2 border-t border-gray-100">
          <div className="flex items-baseline justify-between gap-1">
            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-black text-red-600">
                {formatCurrency(product.price)}
              </span>
              {product.originalPrice > product.price && (
                <span className="text-xs text-gray-400 line-through">
                  {formatCurrency(product.originalPrice)}
                </span>
              )}
            </div>

            {/* Quick in-cart indicator */}
            {cartItem && (
              <span className="text-[11px] font-extrabold text-red-700 bg-red-100/80 px-2 py-0.5 rounded-full">
                {cartItem.quantity} في السلة
              </span>
            )}
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-1.5 mt-3 pt-1">
            {/* Add to cart */}
            <button
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className={`w-full py-2 px-2 rounded-xl text-xs font-black flex items-center justify-center gap-1 transition-all active:scale-95 ${
                !product.inStock
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : justAdded
                  ? 'bg-emerald-600 text-white'
                  : 'bg-red-600 hover:bg-red-700 text-white shadow-xs'
              }`}
            >
              {justAdded ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>تمت الإضافة!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>أضف للسلة</span>
                </>
              )}
            </button>

            {/* Quick WhatsApp order */}
            <button
              onClick={handleWhatsAppQuickOrder}
              className="w-full py-2 px-2 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 flex items-center justify-center gap-1 transition-colors active:scale-95"
              title="طلب سريع فوري عبر واتساب"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span>طلب واتساب</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
