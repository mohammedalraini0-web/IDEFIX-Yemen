import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  Terminal, 
  Check, 
  Copy, 
  AlertCircle, 
  Play, 
  Layers, 
  ShieldCheck, 
  FileCode2 
} from 'lucide-react';
import { STORE_CONFIG } from '../data/initialProducts';

interface AndroidPackagingGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidPackagingGuideModal: React.FC<AndroidPackagingGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const steps = [
    {
      title: 'الخطوة 1: بناء ملفات الويب الجاهزة (Production Build)',
      command: 'npm run build',
      desc: 'يقوم بإنشاء مجلد dist المحتوي على كود التطبيق المترجم والأيقونات وملفات PWA.',
    },
    {
      title: 'الخطوة 2: تهيئة مشروع أندرويد عبر Capacitor',
      command: 'npx cap add android',
      desc: 'ينشئ مجلد android يحتوي على كود Gradle و Android Studio الأصلي.',
    },
    {
      title: 'الخطوة 3: مزامنة كود التطبيق مع منصة أندرويد',
      command: 'npm run android:sync',
      desc: 'ينسخ ملفات dist و capacitor.config.ts إلى مشروع أندرويد.',
    },
    {
      title: 'الخطوة 4: فتح المشروع في Android Studio لتوليد الـ APK',
      command: 'npx cap open android',
      desc: 'يفتح Android Studio مباشرة. من القائمة اختر: Build > Build Bundle(s) / APK(s) > Build APK أو Generate Signed Bundle لنشره على متجر Google Play.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />

      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[92vh] flex flex-col border border-gray-100">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-red-700 to-red-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white">
              <Smartphone className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="font-black text-base sm:text-lg">
                دليل تحزيم تطبيق أندرويد (APK / AAB)
              </h2>
              <p className="text-xs text-red-100 font-medium">
                تطبيق {STORE_CONFIG.name} - {STORE_CONFIG.subName}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-5 no-scrollbar text-right">
          {/* Important Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3.5 flex items-start gap-3 text-xs text-amber-900">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">تنبيه المطورين وتحزيم أندرويد:</p>
              <p className="text-[11px] leading-relaxed text-amber-800">
                تم تجهيز وضبط كافة ملفات التطبيق (Vite PWA, Web Manifest, أيقونات 192 و 512, وملفات Capacitor). بيئات الويب السحابية لا تولد ملفات ثنائية بصيغة APK مباشرة بدون بيئة Android SDK، لذا يمكنك تنزيل المشروع وتنفيذ الأوامر التالية على حاسوبك للحصول على ملف APK أو AAB جاهز للنشر.
              </p>
            </div>
          </div>

          {/* App Metadata Specifications */}
          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 space-y-2 text-xs">
            <h4 className="font-bold text-gray-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>بيانات وهوية التطبيق المحفوظة في الإعدادات:</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-gray-600 pt-1">
              <div>
                <strong>اسم التطبيق:</strong> IDEFIX Yemen
              </div>
              <div>
                <strong>معرف الحزمة (App ID):</strong> com.idefix.yemen.joker
              </div>
              <div>
                <strong>المتجر والفرع:</strong> مركز الجوكر - يريم شارع 20
              </div>
              <div>
                <strong>واتساب الطلبات:</strong> {STORE_CONFIG.whatsappRaw} (+967)
              </div>
              <div>
                <strong>هاتف الاتصال:</strong> {STORE_CONFIG.phoneCallRaw}
              </div>
              <div>
                <strong>العملة الرسمية:</strong> الريال اليمني (YER)
              </div>
            </div>
          </div>

          {/* Packaging steps */}
          <div className="space-y-3">
            <h4 className="font-black text-gray-900 text-sm flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-red-600" />
              <span>خطوات إنشاء ملف APK عبر Capacitor و Android Studio:</span>
            </h4>

            <div className="space-y-2.5">
              {steps.map((step, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl border border-gray-200 bg-white shadow-2xs space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-gray-900">{step.title}</span>
                    <button
                      onClick={() => copyToClipboard(step.command, idx)}
                      className="text-[11px] font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2 py-1 rounded-lg flex items-center gap-1 transition-colors"
                      title="نسخ الأمر"
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>تم النسخ!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>نسخ الأمر</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="bg-gray-900 text-emerald-400 p-2.5 rounded-xl font-mono text-xs text-left ltr select-all">
                    $ {step.command}
                  </div>
                  <p className="text-[11px] text-gray-500">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Alternative: PWA direct installation on Android */}
          <div className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/70 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-emerald-900 font-bold">
              <Play className="w-4 h-4 text-emerald-600" />
              <span>طريقة التثبيت المباشرة والفورية على هواتف العملاء (PWA):</span>
            </div>
            <p className="text-[11px] text-emerald-800 leading-relaxed">
              يمكن لعملاء مركز الجوكر في يريم فتح رابط المتجر مباشرة في متصفح Chrome على هواتف أندرويد والضغط على زر <strong>&quot;تثبيت التطبيق&quot;</strong> الذي أضفناه في الواجهة، ليتم تثبيت التطبيق مباشرة على شاشة الهاتف الرئيسية مع أيقونة المركز وفتح التطبيق بوضع ملء الشاشة Standalone بدون الحاجة لمتجر Google Play!
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 flex justify-end">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 bg-gray-900 hover:bg-black text-white text-xs font-bold rounded-xl transition-colors"
          >
            فهمت، إغلاق الدليل
          </button>
        </div>
      </div>
    </div>
  );
};
