import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Edit3, 
  Package, 
  ShoppingBag, 
  RotateCcw, 
  Check, 
  AlertTriangle, 
  Image as ImageIcon,
  CheckCircle2,
  Phone,
  MapPin,
  Calendar,
  Smartphone,
  Terminal,
  Copy
} from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { Product, CategoryId } from '../types';
import { CATEGORIES, STORE_CONFIG } from '../data/initialProducts';
import { formatCurrency } from '../utils/formatters';

const PRESET_IMAGE_OPTIONS = [
  { label: 'سكر ومؤن', url: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?auto=format&fit=crop&w=800&q=80' },
  { label: 'أرز حبوب', url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=800&q=80' },
  { label: 'زيوت طهي', url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=800&q=80' },
  { label: 'شاي ومشروبات', url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80' },
  { label: 'منظفات وغسيل', url: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&w=800&q=80' },
  { label: 'صابون وجلي', url: 'https://images.unsplash.com/photo-1585670213985-076ed8a94d01?auto=format&fit=crop&w=800&q=80' },
  { label: 'شامبو وعناية', url: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80' },
  { label: 'قدور ومطبخ', url: 'https://images.unsplash.com/photo-1584990347449-3973c91350a4?auto=format&fit=crop&w=800&q=80' },
  { label: 'أجهزة وخلاطات', url: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&w=800&q=80' },
  { label: 'أدوات منزلية', url: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=800&q=80' },
];

export const AdminModal: React.FC = () => {
  const { 
    isAdminOpen, 
    setIsAdminOpen, 
    products, 
    orders, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    resetProductsToDefault 
  } = useShop();

  const [activeTab, setActiveTab] = useState<'products' | 'add' | 'orders' | 'export'>('products');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form states for new or edited product
  const [formData, setFormData] = useState({
    name: '',
    category: 'groceries' as CategoryId,
    price: '',
    originalPrice: '',
    stockCount: '25',
    unit: 'قطعة',
    image: PRESET_IMAGE_OPTIONS[0].url,
    description: '',
    inStock: true,
    badge: 'تخفيض جديد',
  });

  const [formSuccess, setFormSuccess] = useState('');

  if (!isAdminOpen) return null;

  const handleStartEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      price: product.price.toString(),
      originalPrice: product.originalPrice.toString(),
      stockCount: product.stockCount.toString(),
      unit: product.unit,
      image: product.image,
      description: product.description,
      inStock: product.inStock,
      badge: product.badge || '',
    });
    setActiveTab('add');
  };

  const handleResetForm = () => {
    setEditingProduct(null);
    setFormData({
      name: '',
      category: 'groceries',
      price: '',
      originalPrice: '',
      stockCount: '25',
      unit: 'قطعة',
      image: PRESET_IMAGE_OPTIONS[0].url,
      description: '',
      inStock: true,
      badge: 'تخفيض جديد',
    });
    setFormSuccess('');
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price) {
      alert('يرجى ملء اسم المنتج والسعر على الأقل');
      return;
    }

    const priceNum = parseFloat(formData.price) || 0;
    const origPriceNum = parseFloat(formData.originalPrice) || priceNum;
    const stockNum = parseInt(formData.stockCount) || 10;

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: formData.name,
        category: formData.category,
        price: priceNum,
        originalPrice: origPriceNum,
        stockCount: stockNum,
        unit: formData.unit,
        image: formData.image,
        description: formData.description,
        inStock: formData.inStock && stockNum > 0,
        badge: formData.badge,
      });
      setFormSuccess('تم تعديل بيانات المنتج بنجاح!');
    } else {
      addProduct({
        name: formData.name,
        category: formData.category,
        price: priceNum,
        originalPrice: origPriceNum,
        stockCount: stockNum,
        unit: formData.unit,
        image: formData.image,
        description: formData.description || 'منتج أصلي عالي الجودة متوفر بمركز الجوكر للتخفيضات في يريم.',
        inStock: formData.inStock && stockNum > 0,
        badge: formData.badge,
      });
      setFormSuccess('تمت إضافة المنتج الجديد بنجاح إلى المتجر!');
    }

    setTimeout(() => {
      handleResetForm();
      setActiveTab('products');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="fixed inset-0" 
        onClick={() => setIsAdminOpen(false)} 
      />

      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[94vh] flex flex-col border border-gray-100">
        {/* Prototype Warning Banner */}
        <div className="bg-amber-500 text-amber-950 px-4 py-2 text-xs font-bold flex items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-950 shrink-0" />
            <span>
              لوحة تحكم تجريبية (Prototype) - مخصصة لمالك مركز الجوكر. لا توجد قاعدة بيانات حقيقية والبيانات مخزنة بمتصفحك فقط.
            </span>
          </div>
          <span className="text-[10px] bg-amber-950/10 px-2 py-0.5 rounded-full uppercase">
            نسخة تجريبية
          </span>
        </div>

        {/* Modal Top Header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-gray-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-black text-sm sm:text-base">
                لوحة إدارة متجر إيديفيكس اليمن
              </h2>
              <p className="text-[11px] text-gray-400">
                {STORE_CONFIG.subName} - {STORE_CONFIG.city}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (confirm('هل تريد إعادة تعيين المنتجات إلى القائمة الافتراضية؟')) {
                  resetProductsToDefault();
                }
              }}
              className="text-xs bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-colors"
              title="إعادة تعيين المنتجات الافتراضية"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">إعادة ضبط البيانات</span>
            </button>

            <button
              onClick={() => setIsAdminOpen(false)}
              className="p-1 rounded-full text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tabs Bar */}
        <div className="flex border-b border-gray-200 bg-gray-50/80 px-4 text-xs font-bold gap-2">
          <button
            onClick={() => {
              setActiveTab('products');
              handleResetForm();
            }}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'products'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>المنتجات الحالية ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('add')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'add'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{editingProduct ? 'تعديل منتج' : 'إضافة منتج جديد'}</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('orders');
              handleResetForm();
            }}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'orders'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>طلبات العملاء التجريبية ({orders.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('export');
              handleResetForm();
            }}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === 'export'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-600" />
            <span>تحزيم أندرويد (APK / AAB)</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 no-scrollbar">
          {/* TAB 1: PRODUCT LIST */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-gray-500">
                  يمكنك تعديل الأسعار، تغيير حالة التوفر، أو حذف وإضافة المنتجات المعروضة في فرع يريم.
                </p>
                <button
                  onClick={() => {
                    handleResetForm();
                    setActiveTab('add');
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة منتج جديد</span>
                </button>
              </div>

              <div className="overflow-x-auto border border-gray-200 rounded-2xl">
                <table className="w-full text-right text-xs">
                  <thead className="bg-gray-50 border-b border-gray-200 text-gray-600 font-bold">
                    <tr>
                      <th className="p-3">المنتج</th>
                      <th className="p-3">القسم</th>
                      <th className="p-3">سعر البيع (YER)</th>
                      <th className="p-3">السعر الأصلي</th>
                      <th className="p-3">المخزون</th>
                      <th className="p-3">الحالة</th>
                      <th className="p-3 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {products.map((prod) => (
                      <tr key={prod.id} className="hover:bg-gray-50/80 transition-colors">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <img
                              src={prod.image}
                              alt={prod.name}
                              className="w-10 h-10 rounded-lg object-cover border border-gray-200 shrink-0"
                            />
                            <div className="min-w-0">
                              <p className="font-bold text-gray-900 truncate max-w-[180px]">
                                {prod.name}
                              </p>
                              <span className="text-[10px] text-gray-500 bg-gray-100 px-1.5 py-0.2 rounded">
                                {prod.unit}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="p-3 text-gray-600 font-medium">
                          {CATEGORIES.find((c) => c.id === prod.category)?.name || prod.category}
                        </td>

                        <td className="p-3 font-bold text-red-600">
                          {formatCurrency(prod.price)}
                        </td>

                        <td className="p-3 text-gray-400 line-through">
                          {formatCurrency(prod.originalPrice)}
                        </td>

                        <td className="p-3 font-semibold text-gray-800">
                          {prod.stockCount} قطعة
                        </td>

                        <td className="p-3">
                          <button
                            onClick={() => updateProduct(prod.id, { inStock: !prod.inStock })}
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              prod.inStock
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                : 'bg-red-100 text-red-800 hover:bg-red-200'
                            }`}
                          >
                            {prod.inStock ? 'متوفر' : 'غير متوفر'}
                          </button>
                        </td>

                        <td className="p-3">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleStartEdit(prod)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              title="تعديل المنتج"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`هل أنت متأكد من حذف "${prod.name}"؟`)) {
                                  deleteProduct(prod.id);
                                }
                              }}
                              className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="حذف المنتج"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: ADD OR EDIT PRODUCT FORM */}
          {activeTab === 'add' && (
            <form onSubmit={handleFormSubmit} className="max-w-2xl mx-auto space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-gray-100">
                <h3 className="font-black text-gray-900 text-sm">
                  {editingProduct ? `تعديل بيانات: ${editingProduct.name}` : 'إضافة منتج تخفيضات جديد'}
                </h3>
                {editingProduct && (
                  <button
                    type="button"
                    onClick={handleResetForm}
                    className="text-xs text-red-600 font-bold hover:underline"
                  >
                    إلغاء التعديل
                  </button>
                )}
              </div>

              {formSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Product Name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    اسم المنتج بالتفصيل *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: حليب دانو مجفف سريع الذوبان (1800 جم)"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    القسم التابع له *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as CategoryId })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Unit / Pack Size */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    الوحدة أو العبوة *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: كيس 10 كجم أو علبة 1 لتر"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>

                {/* Current Discounted Price */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    سعر البيع المخفض بالريال اليمني (YER) *
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="مثال: 11800"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>

                {/* Original Price */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    السعر الأصلي قبل التخفيض (YER)
                  </label>
                  <input
                    type="number"
                    placeholder="مثال: 13500"
                    value={formData.originalPrice}
                    onChange={(e) => setFormData({ ...formData, originalPrice: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>

                {/* Stock count */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    الكمية المتوفرة بالمخزن
                  </label>
                  <input
                    type="number"
                    value={formData.stockCount}
                    onChange={(e) => setFormData({ ...formData, stockCount: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>

                {/* Badge */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    شارة العرض (اختياري)
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: عرض الأسبوع أو تخفيض خاص"
                    value={formData.badge}
                    onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>

                {/* Image selection */}
                <div className="sm:col-span-2 space-y-2">
                  <label className="block text-xs font-bold text-gray-700 flex items-center justify-between">
                    <span>رابط صورة المنتج أو اختر من النماذج الجاهزة:</span>
                    <ImageIcon className="w-3.5 h-3.5 text-gray-400" />
                  </label>
                  <input
                    type="url"
                    placeholder="https://..."
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                  {/* Preset images buttons */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {PRESET_IMAGE_OPTIONS.map((opt) => (
                      <button
                        key={opt.url}
                        type="button"
                        onClick={() => setFormData({ ...formData, image: opt.url })}
                        className={`text-[10px] font-bold px-2 py-1 rounded-lg border transition-colors ${
                          formData.image === opt.url
                            ? 'bg-red-600 text-white border-red-600'
                            : 'bg-gray-100 text-gray-700 border-gray-200 hover:bg-gray-200'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Description */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-gray-700 mb-1">
                    وصف المنتج
                  </label>
                  <textarea
                    rows={2}
                    placeholder="اكتب وصفاً مختصراً عن جودة وتعبئة المنتج..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 rounded-xl px-3 py-2 text-xs outline-none"
                  />
                </div>
              </div>

              {/* Submit button */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-black text-xs sm:text-sm rounded-xl flex items-center justify-center gap-1.5 shadow-md transition-colors"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingProduct ? 'حفظ التعديلات' : 'إضافة المنتج للمتجر'}</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: DEMO ORDERS LIST */}
          {activeTab === 'orders' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-gray-500">
                  عرض الطلبات التجريبية المحفوظة محلياً أثناء تجربة الشراء من المتجر:
                </p>
                <span className="text-xs font-bold text-gray-700">
                  إجمالي الطلبات: {orders.length}
                </span>
              </div>

              {orders.length === 0 ? (
                <div className="text-center py-10 bg-gray-50 rounded-2xl border border-gray-200">
                  <ShoppingBag className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-xs font-bold text-gray-600">لا توجد طلبات مسجلة بعد</p>
                  <p className="text-[11px] text-gray-400 mt-1">
                    جرب إضافة منتجات إلى السلة واضغط على &quot;إرسال الطلب عبر واتساب&quot; لتظهر هنا
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-4 rounded-2xl border border-gray-200 bg-white shadow-2xs space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-xs bg-red-50 text-red-700 px-2.5 py-1 rounded-lg border border-red-200">
                            #{ord.id}
                          </span>
                          <span className="text-xs font-bold text-gray-900">
                            {ord.customerName}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-gray-500">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{ord.createdAt}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="flex items-center gap-1.5 text-gray-600">
                          <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span dir="ltr">{ord.phoneNumber}</span>
                        </div>

                        <div className="flex items-center gap-1.5 text-gray-600">
                          <MapPin className="w-3.5 h-3.5 text-red-600 shrink-0" />
                          <span className="truncate">{ord.deliveryAddress}</span>
                        </div>
                      </div>

                      {ord.notes && (
                        <p className="text-[11px] text-gray-500 bg-gray-50 p-2 rounded-lg">
                          <strong>ملاحظة العميل:</strong> {ord.notes}
                        </p>
                      )}

                      {/* Items */}
                      <div className="bg-gray-50 rounded-xl p-2.5 space-y-1 text-xs">
                        {ord.items.map((item, idx) => (
                          <div key={idx} className="flex justify-between items-center text-gray-700">
                            <span>
                              {item.productName} ({item.unit}) × {item.quantity}
                            </span>
                            <span className="font-bold">{formatCurrency(item.total)}</span>
                          </div>
                        ))}
                      </div>

                      {/* Total */}
                      <div className="flex justify-between items-center pt-1 text-xs">
                        <span className="font-bold text-gray-500">
                          طريقة الدفع: {ord.paymentMethod === 'cod' ? 'عند الاستلام' : 'كريمي / ون كاش'}
                        </span>
                        <div className="text-right">
                          <span className="text-[11px] text-gray-500 ml-2">المبلغ الإجمالي:</span>
                          <span className="font-black text-sm text-red-600">
                            {formatCurrency(ord.total)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: ANDROID PACKAGING & EXPORT */}
          {activeTab === 'export' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-950">
                <Smartphone className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold text-sm">
                    حالة الجاهزية لتحزيم تطبيق أندرويد (Android Packaging Ready)
                  </p>
                  <p className="text-xs text-emerald-800 leading-relaxed">
                    تم إعداد ملفات المشروع بالكامل لدعم PWA و Capacitor مع ملفات الإعداد <code>capacitor.config.ts</code> وأيقونات أندرويد الرسمية (192x192 و 512x512 و maskable).
                  </p>
                </div>
              </div>

              {/* App Identity summary */}
              <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 text-xs space-y-2">
                <h4 className="font-bold text-gray-900">بيانات الحزمة والتطبيق المعتمدة:</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-gray-700">
                  <div><strong>اسم التطبيق:</strong> {STORE_CONFIG.name}</div>
                  <div><strong>معرف الحزمة (App ID):</strong> com.idefix.yemen.joker</div>
                  <div><strong>المتجر:</strong> {STORE_CONFIG.subName} - يريم، شارع 20</div>
                  <div><strong>واتساب الطلبات:</strong> {STORE_CONFIG.whatsappRaw}</div>
                  <div><strong>هاتف الاتصال:</strong> {STORE_CONFIG.phoneCallRaw}</div>
                  <div><strong>العملة:</strong> الريال اليمني (YER)</div>
                </div>
              </div>

              {/* Step by step terminal commands */}
              <div className="space-y-3">
                <h4 className="font-black text-gray-900 text-xs flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-red-600" />
                  <span>خطوات تحزيم الـ APK على حاسوبك المطور:</span>
                </h4>

                <div className="space-y-2.5 text-xs">
                  <div className="p-3 bg-white border border-gray-200 rounded-xl space-y-1">
                    <p className="font-bold text-gray-800">1. بناء ملفات الإنتاج:</p>
                    <div className="bg-gray-900 text-emerald-400 p-2 rounded-lg font-mono text-[11px] ltr text-left">
                      npm run build
                    </div>
                  </div>

                  <div className="p-3 bg-white border border-gray-200 rounded-xl space-y-1">
                    <p className="font-bold text-gray-800">2. تهيئة مشروع أندرويد (لأول مرة فقط):</p>
                    <div className="bg-gray-900 text-emerald-400 p-2 rounded-lg font-mono text-[11px] ltr text-left">
                      npm run android:init
                    </div>
                  </div>

                  <div className="p-3 bg-white border border-gray-200 rounded-xl space-y-1">
                    <p className="font-bold text-gray-800">3. مزامنة ملفات الويب مع مشروع أندرويد:</p>
                    <div className="bg-gray-900 text-emerald-400 p-2 rounded-lg font-mono text-[11px] ltr text-left">
                      npm run android:sync
                    </div>
                  </div>

                  <div className="p-3 bg-white border border-gray-200 rounded-xl space-y-1">
                    <p className="font-bold text-gray-800">4. فتح المشروع في Android Studio لتوليد الـ APK:</p>
                    <div className="bg-gray-900 text-emerald-400 p-2 rounded-lg font-mono text-[11px] ltr text-left">
                      npm run android:open
                    </div>
                    <p className="text-[11px] text-gray-500 pt-1">
                      في Android Studio اختر: <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> لإنشاء ملف APK تجريبي للتثبيت على الهواتف فوراً، أو <strong>Generate Signed Bundle</strong> لرفعه لمتجر Google Play.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
