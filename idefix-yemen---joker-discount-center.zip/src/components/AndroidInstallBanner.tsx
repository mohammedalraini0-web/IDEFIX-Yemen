import React, { useState } from 'react';
import { Smartphone, X, Download, Check, HelpCircle, Terminal } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidInstallBannerProps {
  onOpenPackagingGuide?: () => void;
}

export const AndroidInstallBanner: React.FC<AndroidInstallBannerProps> = ({
  onOpenPackagingGuide,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [installing, setInstalling] = useState(false);

  // If already running in standalone mode on Android/iOS, suppress banner
  if (isInstalled || dismissed) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      setInstalling(true);
      const success = await install();
      setInstalling(false);
      if (success) setDismissed(true);
    } else {
      setShowGuideModal(true);
    }
  };

  return (
    <>
      <div className="bg-gradient-to-r from-red-900 via-gray-900 to-red-950 text-white p-3 sm:p-3.5 rounded-2xl shadow-md border border-red-800/40 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Smartphone className="w-5 h-5 text-amber-300" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-extrabold text-white text-xs sm:text-sm truncate">
                تطبيق إيديفيكس اليمن على هاتفك الأندرويد
              </p>
              <span className="text-[10px] font-bold bg-emerald-500 text-white px-1.5 py-0.2 rounded-md shrink-0">
                جاهز للتثبيت
              </span>
            </div>
            <p className="text-[11px] text-gray-300 truncate mt-0.5">
              تجربة تسوق سريعة، تصفح خفيف، وإمكانية التحزيم المباشر كـ APK لمتجر Google Play
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Packaging Guide Button */}
          {onOpenPackagingGuide && (
            <button
              onClick={onOpenPackagingGuide}
              className="bg-white/10 hover:bg-white/20 text-red-200 hover:text-white px-2.5 py-1.5 rounded-xl font-bold text-[11px] flex items-center gap-1 transition-colors border border-white/10"
              title="دليل تصدير وتحزيم APK"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>دليل الـ APK</span>
            </button>
          )}

          {/* Install as App Button */}
          <button
            onClick={handleInstallClick}
            disabled={installing}
            className="bg-red-600 hover:bg-red-500 active:scale-95 text-white px-3.5 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-white" />
            <span>{isInstallable ? 'تثبيت التطبيق الآن' : 'كيفية التثبيت'}</span>
          </button>

          <button
            onClick={() => setDismissed(true)}
            className="text-gray-400 hover:text-white p-1 rounded-full transition-colors"
            aria-label="إغلاق التنبيه"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Manual installation modal fallback if beforeinstallprompt is not auto-triggered */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-sm bg-white rounded-3xl p-5 text-right shadow-2xl space-y-4">
            <button
              onClick={() => setShowGuideModal(false)}
              className="absolute top-4 left-4 p-1 rounded-full text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto">
              <Smartphone className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-black text-gray-900 text-base">
                تثبيت التطبيق على جهازك
              </h3>
              <p className="text-xs text-gray-500">
                {isIOS
                  ? 'خطوات التثبيت على أجهزة iPhone / iPad'
                  : 'خطوات التثبيت على هواتف أندرويد عبر متصفح Chrome'}
              </p>
            </div>

            <div className="bg-gray-50 p-3.5 rounded-2xl text-xs space-y-2 text-gray-700 border border-gray-100">
              {isIOS ? (
                <>
                  <p>1. اضغط على زر <strong>المشاركة (Share)</strong> أسفل شاشة المتصفح.</p>
                  <p>2. مرر للأسفل واختر <strong>&quot;إضافة إلى الشاشة الرئيسية&quot; (Add to Home Screen)</strong>.</p>
                  <p>3. اضغط على <strong>&quot;إضافة&quot;</strong> لتظهر أيقونة إيديفيكس اليمن بجوار تطبيقاتك.</p>
                </>
              ) : (
                <>
                  <p>1. اضغط على قائمة الخيارات <strong>(النقاط الثلاث ⋮)</strong> أعلى المتصفح.</p>
                  <p>2. اختر <strong>&quot;تثبيت التطبيق&quot; (Install App)</strong> أو <strong>&quot;إضافة إلى الشاشة الرئيسية&quot;</strong>.</p>
                  <p>3. سيتم تثبيت التطبيق على هاتفك وتشغيله بحجم الشاشة الكاملة كأي تطبيق أندرويد أصلي.</p>
                </>
              )}
            </div>

            <button
              onClick={() => setShowGuideModal(false)}
              className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl"
            >
              حسناً، فهمت
            </button>
          </div>
        </div>
      )}
    </>
  );
};
