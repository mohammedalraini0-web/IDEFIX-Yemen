import React from 'react';
import { 
  Sparkles, 
  MessageCircle, 
  PhoneCall, 
  Truck, 
  BadgePercent, 
  ShieldCheck, 
  MapPin, 
  Users 
} from 'lucide-react';
import { STORE_CONFIG } from '../data/initialProducts';
import { getDirectCallUrl } from '../utils/formatters';
import { useShop } from '../context/ShopContext';

export const BannerSlider: React.FC = () => {
  const { setIsGroupBuyingOpen, setIsInviteModalOpen } = useShop();

  const generalWhatsAppUrl = `https://wa.me/${STORE_CONFIG.whatsappInternational}?text=${encodeURIComponent(
    `السلام عليكم، أتواصل معكم من تطبيق إيديفيكس اليمن (مركز الجوكر للتخفيضات - يريم). أود الاستفسار عن عروض اليوم والتوصيل.`
  )}`;

  return (
    <div className="space-y-4">
      {/* Main Hero Card */}
      <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-red-600 via-red-700 to-rose-800 text-white shadow-xl shadow-red-900/10 border border-red-500">
        {/* Subtle decorative background glow and geometry */}
        <div className="absolute -left-12 -top-12 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-red-400/20 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative p-5 sm:p-8 md:p-10 z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl space-y-3 sm:space-y-4">
            {/* Tag badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs sm:text-sm font-bold border border-white/20">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>أكبر مركز تخفيضات في مدينة يريم</span>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black leading-tight text-white tracking-tight">
              مركز الجوكر للتخفيضات
              <span className="block text-amber-300 text-xl sm:text-3xl font-extrabold mt-1">
                تطبيق إيديفيكس اليمن (IDEFIX)
              </span>
            </h1>

            {/* Description */}
            <p className="text-red-100 text-xs sm:text-base leading-relaxed">
              تسوق كل احتياجات منزلك من المؤن والمواد الغذائية والمنظفات وأدوات المطبخ بأسعار مخفضة في متناول الجميع مع توصيل سريع ومباشر داخل يريم.
            </p>

            {/* Address pill */}
            <div className="flex items-center gap-2 text-xs sm:text-sm text-red-100 bg-red-900/40 w-fit px-3 py-1.5 rounded-lg border border-red-400/30">
              <MapPin className="w-4 h-4 text-amber-300 shrink-0" />
              <span>{STORE_CONFIG.address}</span>
            </div>

            {/* Action buttons */}
            <div className="flex flex-wrap items-center gap-2.5 pt-2">
              <a
                href={generalWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold px-4 sm:px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-900/20 hover:scale-[1.02] active:scale-95 transition-all text-xs sm:text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>اطلب عبر واتساب ({STORE_CONFIG.whatsappRaw})</span>
              </a>

              <a
                href={getDirectCallUrl()}
                className="inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-red-700 font-extrabold px-4 sm:px-5 py-2.5 rounded-xl shadow-md hover:scale-[1.02] active:scale-95 transition-all text-xs sm:text-sm"
              >
                <PhoneCall className="w-4 h-4 text-red-600" />
                <span>اتصال فوري ({STORE_CONFIG.phoneCallRaw})</span>
              </a>
            </div>
          </div>

          {/* Quick promo cards box */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 sm:min-w-[280px] space-y-3">
            <div className="text-xs font-bold text-amber-200 border-b border-white/15 pb-2 flex items-center justify-between">
              <span>مميزات التسوق معنا في يريم</span>
              <BadgePercent className="w-4 h-4" />
            </div>

            <div className="space-y-2.5 text-xs text-red-50">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>توصيل مباشر إلى باب البيت في شارع 20 وضواحي يريم</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>الدفع عند الاستلام نقداً بعد فحص ومطابقة المنتجات</span>
              </div>
              <div className="flex items-center gap-2">
                <BadgePercent className="w-4 h-4 text-amber-300 shrink-0" />
                <span>أسعار الجملة المخفضة بالريال اليمني (YER)</span>
              </div>
            </div>

            {/* Demo interactive features bar inside banner */}
            <div className="pt-2 border-t border-white/15 flex items-center justify-between gap-2">
              <button
                onClick={() => setIsGroupBuyingOpen(true)}
                className="text-[11px] font-bold bg-white/20 hover:bg-white/30 text-white px-2 py-1.5 rounded-lg flex-1 text-center transition-colors"
              >
                صفقات الشراء الجماعي
              </button>
              <button
                onClick={() => setIsInviteModalOpen(true)}
                className="text-[11px] font-bold bg-amber-400 hover:bg-amber-300 text-red-950 px-2 py-1.5 rounded-lg flex-1 text-center transition-colors"
              >
                كوبون 1,500 ر.ي هدية
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Quick reassurance strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 sm:gap-3 text-xs sm:text-sm">
        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-2xs flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center shrink-0">
            <BadgePercent className="w-4 h-4" />
          </div>
          <div>
            <p className="font-bold text-gray-900 leading-tight">تخفيضات أسبوعية</p>
            <p className="text-[11px] text-gray-500">وفر في كل عملية شراء</p>
          </div>
        </div>

        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-2xs flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Truck className="w-4 h-4" />
          </div>
          <div>
            <p className="font-bold text-gray-900 leading-tight">توصيل سريع بـ يريم</p>
            <p className="text-[11px] text-gray-500">شارع 20 وكافة الأحياء</p>
          </div>
        </div>

        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-2xs flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <p className="font-bold text-gray-900 leading-tight">الدفع عند الاستلام</p>
            <p className="text-[11px] text-gray-500">أو تحويل كريمي / ون كاش</p>
          </div>
        </div>

        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-2xs flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <MessageCircle className="w-4 h-4" />
          </div>
          <div>
            <p className="font-bold text-gray-900 leading-tight">تأكيد طلب بالواتساب</p>
            <p className="text-[11px] text-gray-500">خدمة عملاء مباشرة 739995991</p>
          </div>
        </div>
      </div>
    </div>
  );
};
