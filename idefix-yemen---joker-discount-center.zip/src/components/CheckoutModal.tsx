import React, { useState } from 'react';
import { 
  X, 
  MessageCircle, 
  MapPin, 
  User, 
  Phone, 
  FileText, 
  ShieldCheck, 
  Truck, 
  CreditCard,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useShop } from '../context/ShopContext';
import { STORE_CONFIG } from '../data/initialProducts';
import { formatCurrency, buildWhatsAppOrderUrl } from '../utils/formatters';

export const CheckoutModal: React.FC = () => {
  const { 
    isCheckoutOpen, 
    setIsCheckoutOpen, 
    cart, 
    cartSubtotal, 
    cartDiscount, 
    cartTotal, 
    placeOrder,
    activeCoupon
  } = useShop();

  const [customerName, setCustomerName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'kuraimi_onecash'>('cod');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  if (!isCheckoutOpen) return null;

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!customerName.trim()) {
      errs.customerName = 'يرجى كتابة الاسم الكامل';
    }
    if (!phoneNumber.trim()) {
      errs.phoneNumber = 'يرجى إدخال رقم الهاتف للتواصل';
    } else if (phoneNumber.trim().length < 8) {
      errs.phoneNumber = 'يرجى إدخال رقم هاتف يمني صحيح (مثال: 77XXXXXXX)';
    }
    if (!deliveryAddress.trim()) {
      errs.deliveryAddress = 'يرجى كتابة عنوان التوصيل داخل يريم (الحي / الشارع / أقرب معلم)';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // 1. Create order object & save locally
    const createdOrder = placeOrder({
      customerName: customerName.trim(),
      phoneNumber: phoneNumber.trim(),
      deliveryAddress: deliveryAddress.trim(),
      notes: notes.trim(),
      paymentMethod,
    });

    // 2. Trigger celebratory confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#DC2626', '#10B981', '#F59E0B', '#EF4444'],
      });
    } catch (err) {
      console.log('Confetti effect', err);
    }

    // 3. Generate WhatsApp prefilled link
    const whatsappUrl = buildWhatsAppOrderUrl(createdOrder);

    // 4. Open WhatsApp in new tab / app
    window.open(whatsappUrl, '_blank');

    // 5. Close checkout dialog
    setIsCheckoutOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Backdrop */}
      <div 
        className="fixed inset-0" 
        onClick={() => setIsCheckoutOpen(false)} 
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[94vh] flex flex-col border border-gray-100">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100 bg-red-600 text-white">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-amber-300" />
            <div>
              <h2 className="font-black text-base sm:text-lg">إتمام الطلب والتوصيل</h2>
              <p className="text-xs text-red-100 font-medium">
                {STORE_CONFIG.subName} - يريم
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmitOrder} className="overflow-y-auto p-4 sm:p-6 space-y-4 no-scrollbar">
          {/* Order Brief Summary */}
          <div className="bg-red-50/70 p-3.5 rounded-2xl border border-red-100 space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-gray-700">
              <span>عدد المنتجات في الطلب:</span>
              <span>{cart.length} أصناف</span>
            </div>
            {activeCoupon && (
              <div className="flex justify-between items-center text-xs text-emerald-700 font-bold">
                <span>خصم الكوبون ({activeCoupon.code}):</span>
                <span>-{formatCurrency(cartDiscount)}</span>
              </div>
            )}
            <div className="flex justify-between items-baseline pt-1 border-t border-red-200/60">
              <span className="text-xs font-black text-gray-900">المبلغ الصافي المطلوب:</span>
              <span className="text-xl font-black text-red-600">{formatCurrency(cartTotal)}</span>
            </div>
          </div>

          {/* Customer Inputs */}
          <div className="space-y-3.5">
            {/* Customer Name */}
            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-red-600" />
                <span>الاسم الكامل <span className="text-red-500">*</span></span>
              </label>
              <input
                type="text"
                placeholder="مثال: محمد صالح أحمد"
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  if (errors.customerName) setErrors((prev) => ({ ...prev, customerName: '' }));
                }}
                className={`w-full bg-gray-50 border rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-gray-900 outline-none transition-colors ${
                  errors.customerName ? 'border-red-500 bg-red-50/30' : 'border-gray-200 focus:border-red-500 focus:bg-white'
                }`}
              />
              {errors.customerName && (
                <p className="text-[11px] text-red-600 font-semibold mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.customerName}</span>
                </p>
              )}
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-red-600" />
                <span>رقم الهاتف للتواصل وتأكيد الطلب <span className="text-red-500">*</span></span>
              </label>
              <input
                type="tel"
                placeholder="مثال: 773123456 أو 739995991"
                value={phoneNumber}
                onChange={(e) => {
                  setPhoneNumber(e.target.value);
                  if (errors.phoneNumber) setErrors((prev) => ({ ...prev, phoneNumber: '' }));
                }}
                dir="ltr"
                className={`w-full text-right bg-gray-50 border rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-gray-900 outline-none transition-colors ${
                  errors.phoneNumber ? 'border-red-500 bg-red-50/30' : 'border-gray-200 focus:border-red-500 focus:bg-white'
                }`}
              />
              {errors.phoneNumber && (
                <p className="text-[11px] text-red-600 font-semibold mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.phoneNumber}</span>
                </p>
              )}
            </div>

            {/* Delivery Address */}
            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-red-600" />
                <span>عنوان التوصيل في يريم (الحي / الشارع / أقرب معلم) <span className="text-red-500">*</span></span>
              </label>
              <textarea
                rows={2}
                placeholder="مثال: يريم - شارع 20 - عمارة الشامي - جوار مخابز ريماس أو مستشفى يريم"
                value={deliveryAddress}
                onChange={(e) => {
                  setDeliveryAddress(e.target.value);
                  if (errors.deliveryAddress) setErrors((prev) => ({ ...prev, deliveryAddress: '' }));
                }}
                className={`w-full bg-gray-50 border rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-gray-900 outline-none transition-colors resize-none ${
                  errors.deliveryAddress ? 'border-red-500 bg-red-50/30' : 'border-gray-200 focus:border-red-500 focus:bg-white'
                }`}
              />
              {errors.deliveryAddress && (
                <p className="text-[11px] text-red-600 font-semibold mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.deliveryAddress}</span>
                </p>
              )}
            </div>

            {/* Order Notes */}
            <div>
              <label className="block text-xs font-bold text-gray-800 mb-1 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-gray-500" />
                <span>ملاحظات إضافية للمندوب (اختياري)</span>
              </label>
              <input
                type="text"
                placeholder="مثال: يرجى التوصيل بعد العصر أو ترك الطلب في البقالة المجاورة"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 focus:border-red-500 focus:bg-white rounded-xl px-3.5 py-2 text-xs sm:text-sm text-gray-900 outline-none transition-colors"
              />
            </div>

            {/* Payment Method Option */}
            <div className="pt-1">
              <label className="block text-xs font-bold text-gray-800 mb-2">طريقة الدفع:</label>
              <div className="grid grid-cols-2 gap-2">
                <label className={`p-3 rounded-xl border cursor-pointer flex flex-col gap-1 transition-all ${
                  paymentMethod === 'cod' ? 'border-red-500 bg-red-50/60 ring-1 ring-red-500' : 'border-gray-200 bg-white hover:bg-gray-50'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                    className="sr-only"
                  />
                  <div className="flex items-center gap-1.5 text-xs font-bold text-gray-900">
                    <ShieldCheck className="w-3.5 h-3.5 text-red-600" />
                    <span>الدفع عند الاستلام</span>
                  </div>
                  <span className="text-[10px] text-gray-500">نقداً للمندوب عند باب المنزل في يريم</span>
                </label>

                <label className={`p-3 rounded-xl border cursor-pointer flex flex-col gap-1 transition-all ${
                  paymentMethod === 'kuraimi_onecash' ? 'border-red-500 bg-red-50/60 ring-1 ring-red-500' : 'border-gray-200 bg-white hover:bg-gray-50'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'kuraimi_onecash'}
                    onChange={() => setPaymentMethod('kuraimi_onecash')}
                    className="sr-only"
                  />
                  <div className="flex items-center gap-1.5 text-xs font-bold text-gray-900">
                    <CreditCard className="w-3.5 h-3.5 text-red-600" />
                    <span>حساب الكريمي / ون كاش</span>
                  </div>
                  <span className="text-[10px] text-gray-500">تحويل إلكتروني مباشر وتأكيد عبر واتساب</span>
                </label>
              </div>
            </div>
          </div>

          {/* Direct WhatsApp Action Button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm sm:text-base rounded-2xl shadow-xl shadow-emerald-600/25 flex items-center justify-center gap-2.5 transition-all active:scale-95 group"
            >
              <MessageCircle className="w-5 h-5 text-white animate-pulse" />
              <span>إرسال الطلب عبر واتساب</span>
            </button>
            <p className="text-[11px] text-center text-gray-500 mt-2">
              سيتم فتح واتساب تلقائياً بالرقم <strong>{STORE_CONFIG.whatsappRaw}</strong> مع تفاصيل طلبك الكاملة
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};
