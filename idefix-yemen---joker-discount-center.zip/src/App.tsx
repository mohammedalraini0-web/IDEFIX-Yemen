/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState, useEffect } from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { Header } from './components/Header';
import { BannerSlider } from './components/BannerSlider';
import { CategoryFilter } from './components/CategoryFilter';
import { ProductCard } from './components/ProductCard';
import { ProductDetailsModal } from './components/ProductDetailsModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { GroupBuyingSection } from './components/GroupBuyingSection';
import { InviteFriendsModal } from './components/InviteFriendsModal';
import { AdminModal } from './components/AdminModal';
import { AndroidInstallBanner } from './components/AndroidInstallBanner';
import { AndroidPackagingGuideModal } from './components/AndroidPackagingGuideModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { BottomNav } from './components/BottomNav';
import { Footer } from './components/Footer';
import { CATEGORIES } from './data/initialProducts';
import { ShoppingBag, Search, Sparkles, FilterX } from 'lucide-react';

const MainContent: React.FC = () => {
  const { 
    products, 
    searchQuery, 
    setSearchQuery, 
    selectedCategory, 
    setSelectedCategory,
    selectedProduct,
    setSelectedProduct,
    isCartOpen,
    setIsCartOpen,
    isCheckoutOpen,
    setIsCheckoutOpen,
    isAdminOpen,
    setIsAdminOpen,
    isGroupBuyingOpen,
    setIsGroupBuyingOpen,
    isInviteModalOpen,
    setIsInviteModalOpen,
    lastCompletedOrder,
    setLastCompletedOrder
  } = useShop();

  const [isPackagingGuideOpen, setIsPackagingGuideOpen] = useState(false);

  // Android back button / Escape key handling to gracefully close open modals
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isPackagingGuideOpen) setIsPackagingGuideOpen(false);
        else if (selectedProduct) setSelectedProduct(null);
        else if (isCheckoutOpen) setIsCheckoutOpen(false);
        else if (isCartOpen) setIsCartOpen(false);
        else if (isAdminOpen) setIsAdminOpen(false);
        else if (isGroupBuyingOpen) setIsGroupBuyingOpen(false);
        else if (isInviteModalOpen) setIsInviteModalOpen(false);
        else if (lastCompletedOrder) setLastCompletedOrder(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isPackagingGuideOpen,
    selectedProduct,
    isCheckoutOpen,
    isCartOpen,
    isAdminOpen,
    isGroupBuyingOpen,
    isInviteModalOpen,
    lastCompletedOrder,
    setSelectedProduct,
    setIsCheckoutOpen,
    setIsCartOpen,
    setIsAdminOpen,
    setIsGroupBuyingOpen,
    setIsInviteModalOpen,
    setLastCompletedOrder,
  ]);

  // Filter products based on selected category and search input
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        selectedCategory === 'all' || product.category === selectedCategory;

      const cleanQuery = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !cleanQuery ||
        product.name.toLowerCase().includes(cleanQuery) ||
        product.description.toLowerCase().includes(cleanQuery) ||
        product.unit.toLowerCase().includes(cleanQuery);

      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  const activeCategoryName =
    selectedCategory === 'all'
      ? 'جميع الأقسام'
      : CATEGORIES.find((c) => c.id === selectedCategory)?.name || '';

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-between text-gray-900 pb-16 md:pb-0">
      {/* Offline Alert Indicator */}
      <OfflineIndicator />

      {/* Top Header */}
      <Header />

      {/* Main Body */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-6 sm:space-y-8 flex-1 w-full">
        {/* Android PWA Install Prompt Banner with Guide Link */}
        <AndroidInstallBanner onOpenPackagingGuide={() => setIsPackagingGuideOpen(true)} />

        {/* Hero Banner with Yarim discounts & WhatsApp order button */}
        <BannerSlider />

        {/* Categories Section */}
        <div id="categories-section" className="pt-2">
          <CategoryFilter />
        </div>

        {/* Products Listing Area */}
        <section className="space-y-4">
          {/* Header of Section */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-200/80 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shadow-xs">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base sm:text-xl font-black text-gray-900">
                  {searchQuery ? `نتائج البحث عن "${searchQuery}"` : activeCategoryName}
                </h2>
                <p className="text-xs text-gray-500">
                  عرض {filteredProducts.length} منتجات بأسعار الريال اليمني (YER)
                </p>
              </div>
            </div>

            {/* Reset Filter Button if search or category is active */}
            {(selectedCategory !== 'all' || searchQuery) && (
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                }}
                className="text-xs font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <FilterX className="w-3.5 h-3.5" />
                <span>إعادة ضبط الفلاتر</span>
              </button>
            )}
          </div>

          {/* Grid of Product Cards */}
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 sm:p-12 text-center border border-gray-200 space-y-4">
              <div className="w-16 h-16 rounded-full bg-red-50 text-red-500 flex items-center justify-center mx-auto">
                <Search className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-base sm:text-lg text-gray-900">
                  لم نتمكن من العثور على منتجات مطابقة
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 max-w-sm mx-auto">
                  تأكد من كتابة اسم المنتج بشكل صحيح أو استكشف أقسام مركز الجوكر الأخرى في يريم.
                </p>
              </div>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                }}
                className="bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-red-700 transition-colors"
              >
                عرض كافة منتجات المتجر
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </section>

        {/* Interactive Group Buying Section (Clearly labeled demo) */}
        <GroupBuyingSection />
      </main>

      {/* Footer with Yarim address, phones & hours */}
      <Footer />

      {/* Mobile Android Bottom Navigation & Floating actions */}
      <BottomNav />

      {/* Modals & Overlays */}
      <ProductDetailsModal />
      <CartDrawer />
      <CheckoutModal />
      <OrderSuccessModal />
      <AdminModal />
      <GroupBuyingSection isModal={true} />
      <InviteFriendsModal />
      <AndroidPackagingGuideModal
        isOpen={isPackagingGuideOpen}
        onClose={() => setIsPackagingGuideOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ShopProvider>
      <MainContent />
    </ShopProvider>
  );
}
