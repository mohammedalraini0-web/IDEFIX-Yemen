export type CategoryId = 'all' | 'groceries' | 'cleaning' | 'personal_care' | 'kitchen' | 'household';

export interface Category {
  id: CategoryId;
  name: string;
  iconName: string;
  description: string;
}

export interface Product {
  id: string;
  name: string;
  category: CategoryId;
  price: number; // Yemeni Rial (YER)
  originalPrice: number; // Yemeni Rial (YER)
  image: string;
  description: string;
  unit: string; // e.g. "كيس 10 كجم", "عبوة 3 لتر", "قطعة"
  inStock: boolean;
  stockCount: number;
  featured?: boolean;
  badge?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CustomerOrder {
  id: string;
  customerName: string;
  phoneNumber: string;
  deliveryAddress: string;
  notes?: string;
  paymentMethod: 'cod' | 'kuraimi_onecash';
  items: {
    productId: string;
    productName: string;
    unit: string;
    quantity: number;
    price: number;
    total: number;
  }[];
  subtotal: number;
  discountAmount: number;
  couponCode?: string;
  total: number;
  createdAt: string;
  status: 'pending_whatsapp' | 'confirmed' | 'delivered';
}

export interface GroupDeal {
  id: string;
  title: string;
  productName: string;
  image: string;
  targetCount: number;
  currentCount: number;
  regularPrice: number;
  groupPrice: number;
  savingsPercentage: number;
  expiresInHours: number;
  neighborhood: string;
}
