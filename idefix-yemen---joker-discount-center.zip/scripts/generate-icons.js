import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

// Ensure public directory exists
const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Create public/icon.svg
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#EF4444" />
      <stop offset="50%" stop-color="#DC2626" />
      <stop offset="100%" stop-color="#991B1B" />
    </linearGradient>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#7F1D1D" flood-opacity="0.4" />
    </filter>
  </defs>

  <!-- Background rounded rect -->
  <rect width="512" height="512" rx="110" fill="url(#grad)" />

  <!-- Inner safe border -->
  <rect x="24" y="24" width="464" height="464" rx="90" fill="none" stroke="#FFFFFF" stroke-opacity="0.15" stroke-width="4" />

  <!-- Center Circle Surface -->
  <circle cx="256" cy="256" r="175" fill="#FFFFFF" filter="url(#shadow)" />

  <!-- Joker 'J' in Crimson Red with styling -->
  <text x="256" y="325" font-family="'Cairo', Arial, sans-serif" font-size="220" font-weight="900" text-anchor="middle" fill="#DC2626">J</text>

  <!-- Yemen Star / Discount Badge -->
  <circle cx="370" cy="155" r="42" fill="#DC2626" />
  <text x="370" y="166" font-family="Arial, sans-serif" font-size="34" font-weight="900" text-anchor="middle" fill="#FFFFFF">%</text>

  <!-- Store Name Ribbon at bottom -->
  <rect x="110" y="405" width="292" height="44" rx="22" fill="#FFFFFF" />
  <text x="256" y="434" font-family="'Cairo', Arial, sans-serif" font-size="20" font-weight="900" text-anchor="middle" fill="#DC2626">IDEFIX YEMEN</text>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent, 'utf-8');

/**
 * Minimal pure Node.js PNG encoder that produces valid uncompressed/DEFLATE PNGs
 * without external dependencies.
 */
function createSolidPng(width, height, r, g, b, a = 255) {
  // Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // bit depth: 8
  ihdr.writeUInt8(6, 9); // color type: 6 (RGBA)
  ihdr.writeUInt8(0, 10); // compression method
  ihdr.writeUInt8(0, 11); // filter method
  ihdr.writeUInt8(0, 12); // interlace method

  const ihdrChunk = createChunk('IHDR', ihdr);

  // Raw image data with 0 filter byte per scanline
  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(height * rowSize);

  // Center radius for the white circular badge in icon
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = width * 0.35;
  const radiusSq = radius * radius;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter type: None

    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = x - centerX;
      const dy = y - centerY;
      const distSq = dx * dx + dy * dy;

      // Draw red background with white center circle
      if (distSq <= radiusSq) {
        // White inside circle
        rawData[pxOffset] = 255;
        rawData[pxOffset + 1] = 255;
        rawData[pxOffset + 2] = 255;
        rawData[pxOffset + 3] = 255;
      } else {
        // Red #DC2626 background
        rawData[pxOffset] = r;
        rawData[pxOffset + 1] = g;
        rawData[pxOffset + 2] = b;
        rawData[pxOffset + 3] = a;
      }
    }
  }

  const deflated = zlib.deflateSync(rawData);
  const idatChunk = createChunk('IDAT', deflated);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const length = data.length;
  const chunk = Buffer.alloc(12 + length);
  chunk.writeUInt32BE(length, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);

  const crcData = chunk.subarray(4, 8 + length);
  const crc = crc32(crcData);
  chunk.writeUInt32BE(crc, 8 + length);

  return chunk;
}

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    let byte = buf[i];
    crc = crc ^ byte;
    for (let j = 0; j < 8; j++) {
      const mask = -(crc & 1);
      crc = (crc >>> 1) ^ (0xedb88320 & mask);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Generate PNGs: 192x192, 512x512, maskable 512x512, apple-touch-icon 180x180
const png192 = createSolidPng(192, 192, 220, 38, 38);
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), png192);

const png512 = createSolidPng(512, 512, 220, 38, 38);
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), png512);

// Maskable icon with 15% safe padding
const pngMaskable512 = createSolidPng(512, 512, 185, 28, 28);
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pngMaskable512);

const appleIcon = createSolidPng(180, 180, 220, 38, 38);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), appleIcon);

// Favicon
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), png192);

console.log('Successfully created all Android & PWA icons in /public');
